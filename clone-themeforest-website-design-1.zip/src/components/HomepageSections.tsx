import { useState } from 'react';
import {
  Award,
  BookOpen,
  ShieldCheck,
  Sparkles,
  ArrowRight,
  MapPin,
  Calendar,
} from 'lucide-react';
import {
  FEATURED_CREATOR,
  MainCategory,
  ThemeItem,
} from '../data/marketplaceData';
import { ThemeCard } from './ThemeCard';

interface HomepageSectionsProps {
  allItems: ThemeItem[];
  cartIds: number[];
  favoriteIds: number[];
  onInspect: (item: ThemeItem) => void;
  onLivePreview: (item: ThemeItem) => void;
  onAddToCart: (item: ThemeItem) => void;
  onToggleFavorite: (item: ThemeItem) => void;
  onOpenCatalog: (category?: MainCategory, sort?: 'newest' | 'bestseller', author?: string) => void;
  onOpenElements: () => void;
}

const NEWEST_FILTER_TABS: MainCategory[] = [
  'All Items',
  'WordPress',
  'eCommerce',
  'Site Templates',
  'Marketing',
  'CMS',
  'UI Templates',
  'Blogging',
];

export function HomepageSections({
  allItems,
  cartIds,
  favoriteIds,
  onInspect,
  onLivePreview,
  onAddToCart,
  onToggleFavorite,
  onOpenCatalog,
  onOpenElements,
}: HomepageSectionsProps) {
  const [newestCategory, setNewestCategory] = useState<MainCategory>('All Items');

  const budgetItems = allItems.filter((i) => i.sectionTags.includes('budget')).slice(0, 4);
  const featuredItems = allItems.filter((i) => i.sectionTags.includes('featured')).slice(0, 4);
  const largestItems = allItems.filter((i) => i.sectionTags.includes('largest')).slice(0, 4);
  const creatorItems = allItems.filter((i) => i.sectionTags.includes('creator')).slice(0, 3);
  const bestsellerItems = allItems.filter((i) => i.sectionTags.includes('bestseller')).slice(0, 4);

  const newestPool =
    newestCategory === 'All Items'
      ? allItems.filter((i) => i.sectionTags.includes('newest')).slice(0, 8)
      : allItems.filter((i) => i.category === newestCategory).slice(0, 8);

  return (
    <>
      {/* 1. "Unique themes and templates for every budget and every project." */}
      <section className="bg-white py-14 border-t border-[#EEEEEE]">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6">
          <div className="text-center max-w-[680px] mx-auto mb-10">
            <h2 className="text-[24px] sm:text-[28px] font-bold text-[#262626] tracking-tight">
              Unique themes and templates for every budget and every project.
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {budgetItems.map((item) => (
              <ThemeCard
                key={item.id}
                item={item}
                isInCart={cartIds.includes(item.id)}
                isFavorite={favoriteIds.includes(item.id)}
                onInspect={onInspect}
                onLivePreview={onLivePreview}
                onAddToCart={onAddToCart}
                onToggleFavorite={onToggleFavorite}
                onFilterByAuthor={(author) => onOpenCatalog('All Items', undefined, author)}
              />
            ))}
          </div>

          <div className="mt-10 text-center">
            <button
              type="button"
              onClick={() => onOpenCatalog('All Items')}
              className="tf-btn-green px-7 py-3 rounded text-[14px] font-semibold inline-flex items-center gap-2 cursor-pointer"
            >
              <span>View all themes</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </section>

      {/* 2. Envato Elements Unlimited Downloads Banner */}
      <section className="bg-[#262626] text-white py-9">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-1.5 text-center md:text-left">
            <div className="inline-flex items-center gap-2 text-[#82B541] text-[12px] font-bold uppercase tracking-wider">
              <Sparkles className="w-4 h-4" />
              <span>Envato Elements Subscription</span>
            </div>
            <h3 className="text-[20px] sm:text-[22px] font-bold leading-snug">
              Get unlimited downloads across Web Templates, Stock Video, Creative Assets and more.
            </h3>
            <p className="text-[14px] text-[#BDBDBD]">
              The world&apos;s broadest stock catalog with purpose-built AI — all under one simple commercial license.
            </p>
          </div>
          <button
            type="button"
            onClick={onOpenElements}
            className="tf-btn-green px-6 py-3 rounded font-semibold text-[14px] whitespace-nowrap shrink-0 cursor-pointer"
          >
            Explore Unlimited Downloads
          </button>
        </div>
      </section>

      {/* 3. "Featured themes" Asymmetric Section */}
      <section className="bg-[#F5F5F5] py-14 border-b border-[#E8ECEF]">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Left Intro Block */}
            <div className="lg:col-span-4 space-y-4">
              <span className="inline-block text-[11px] font-bold uppercase tracking-wider text-[#6F9A37] bg-[#82B541]/15 px-2.5 py-1 rounded">
                Staff Picks
              </span>
              <h2 className="text-[26px] sm:text-[30px] font-bold text-[#262626] leading-tight">
                Featured themes
              </h2>
              <p className="text-[15px] text-[#555555] leading-relaxed">
                Every week, our staff personally hand-pick some of the best new website themes from our collection.
              </p>
              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => onOpenCatalog('WordPress', 'newest')}
                  className="tf-btn-green px-6 py-2.5 rounded text-[14px] font-semibold inline-flex items-center gap-2 cursor-pointer"
                >
                  <span>View all featured themes</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Right 2x2 Grid */}
            <div className="lg:col-span-8 grid grid-cols-1 sm:grid-cols-2 gap-6">
              {featuredItems.map((item) => (
                <ThemeCard
                  key={item.id}
                  item={item}
                  isInCart={cartIds.includes(item.id)}
                  isFavorite={favoriteIds.includes(item.id)}
                  onInspect={onInspect}
                  onLivePreview={onLivePreview}
                  onAddToCart={onAddToCart}
                  onToggleFavorite={onToggleFavorite}
                  onFilterByAuthor={(author) => onOpenCatalog('All Items', undefined, author)}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* 4. "We're the largest theme marketplace in the world" + 3 Value Propositions */}
      <section className="bg-white py-14 border-b border-[#EEEEEE]">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6">
          <div className="text-center max-w-[680px] mx-auto mb-10">
            <h2 className="text-[24px] sm:text-[28px] font-bold text-[#262626]">
              We&apos;re the largest theme marketplace in the world
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {largestItems.map((item) => (
              <ThemeCard
                key={item.id}
                item={item}
                isInCart={cartIds.includes(item.id)}
                isFavorite={favoriteIds.includes(item.id)}
                onInspect={onInspect}
                onLivePreview={onLivePreview}
                onAddToCart={onAddToCart}
                onToggleFavorite={onToggleFavorite}
                onFilterByAuthor={(author) => onOpenCatalog('All Items', undefined, author)}
              />
            ))}
          </div>

          {/* 3 Value Propositions */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-14 pt-10 border-t border-[#F0F2F4]">
            <div className="flex flex-col items-center text-center space-y-3 px-4">
              <div className="w-14 h-14 rounded-full bg-[#F1F8EC] text-[#7AB55C] flex items-center justify-center border border-[#DDF0CE]">
                <Award className="w-7 h-7" />
              </div>
              <p className="text-[16px] font-semibold text-[#333333] max-w-[260px]">
                Home of the most popular themes in the world
              </p>
            </div>

            <div className="flex flex-col items-center text-center space-y-3 px-4">
              <div className="w-14 h-14 rounded-full bg-[#EEF6FA] text-[#21759B] flex items-center justify-center border border-[#D4E9F4]">
                <BookOpen className="w-7 h-7" />
              </div>
              <p className="text-[16px] font-semibold text-[#333333] max-w-[260px]">
                Clear documentation and theme support available
              </p>
            </div>

            <div className="flex flex-col items-center text-center space-y-3 px-4">
              <div className="w-14 h-14 rounded-full bg-[#FFF5EB] text-[#F57D00] flex items-center justify-center border border-[#FDE2C4]">
                <ShieldCheck className="w-7 h-7" />
              </div>
              <p className="text-[16px] font-semibold text-[#333333] max-w-[260px]">
                Quality reviewed creators and items
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 5. "Check out our newest themes and templates" (Filterable) */}
      <section className="bg-[#F5F5F5] py-14 border-b border-[#E8ECEF]">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6">
          <div className="text-center max-w-[740px] mx-auto mb-8 space-y-2.5">
            <h2 className="text-[24px] sm:text-[28px] font-bold text-[#262626]">
              Check out our newest themes and templates
            </h2>
            <p className="text-[15px] text-[#555555] leading-relaxed">
              We carefully review new entries from our community one by one to make sure they meet
              high-quality design and functionality standards. From multipurpose themes to niche
              templates, you&apos;ll always find something that catches your eye.
            </p>
          </div>

          {/* Filter Pills */}
          <div className="flex flex-wrap items-center justify-center gap-2 mb-8">
            {NEWEST_FILTER_TABS.map((cat) => {
              const active = newestCategory === cat;
              return (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setNewestCategory(cat)}
                  className={`px-4 py-2 rounded-full text-[13px] font-semibold transition-all cursor-pointer ${
                    active
                      ? 'bg-[#262626] text-white shadow-sm'
                      : 'bg-white text-[#555555] border border-[#DCE1E5] hover:border-[#999999] hover:text-[#262626]'
                  }`}
                >
                  {cat === 'All Items' ? 'All categories' : cat}
                </button>
              );
            })}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {newestPool.map((item) => (
              <ThemeCard
                key={item.id}
                item={item}
                isInCart={cartIds.includes(item.id)}
                isFavorite={favoriteIds.includes(item.id)}
                onInspect={onInspect}
                onLivePreview={onLivePreview}
                onAddToCart={onAddToCart}
                onToggleFavorite={onToggleFavorite}
                onFilterByAuthor={(author) => onOpenCatalog('All Items', undefined, author)}
              />
            ))}
          </div>

          <div className="mt-10 text-center">
            <button
              type="button"
              onClick={() => onOpenCatalog(newestCategory, 'newest')}
              className="bg-white hover:bg-[#FAFAFA] text-[#333333] border border-[#CCCCCC] hover:border-[#999999] px-7 py-2.5 rounded text-[14px] font-semibold inline-flex items-center gap-2 transition-colors cursor-pointer"
            >
              <span>View more new items</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </section>

      {/* 6. "Featured creator" (axiomthemes) */}
      <section className="bg-white py-14 border-b border-[#EEEEEE]">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Creator Bio Column */}
            <div className="lg:col-span-4 space-y-5">
              <div className="space-y-1">
                <span className="text-[11px] font-bold uppercase tracking-wider text-[#6F9A37]">
                  Author Spotlight
                </span>
                <h2 className="text-[26px] sm:text-[28px] font-bold text-[#262626]">
                  Featured creator
                </h2>
              </div>

              <div className="bg-[#F9FAFB] border border-[#E6E9EC] rounded-lg p-5 space-y-4">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-lg bg-[#262626] text-white flex items-center justify-center font-extrabold text-[22px] shadow-sm shrink-0">
                    AX
                  </div>
                  <div className="min-w-0">
                    <h3 className="text-[18px] font-bold text-[#262626] truncate">
                      {FEATURED_CREATOR.username}
                    </h3>
                    <div className="flex items-center gap-1.5 text-[12px] text-[#666666] mt-0.5">
                      <MapPin className="w-3.5 h-3.5 text-[#888888]" />
                      <span>{FEATURED_CREATOR.location}</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-[12px] text-[#666666] mt-0.5">
                      <Calendar className="w-3.5 h-3.5 text-[#888888]" />
                      <span>Member since {FEATURED_CREATOR.memberSince}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 pt-1">
                  <span className="inline-flex items-center gap-1 bg-amber-100 text-amber-900 border border-amber-200 px-2.5 py-0.5 rounded-full text-[11px] font-bold">
                    <Award className="w-3 h-3" />
                    {FEATURED_CREATOR.badge}
                  </span>
                  <span className="text-[12px] font-semibold text-[#555555]">
                    {FEATURED_CREATOR.totalSales} Sales
                  </span>
                </div>

                <p className="text-[13.5px] text-[#555555] leading-relaxed">
                  {FEATURED_CREATOR.bio}
                </p>

                <button
                  type="button"
                  onClick={() => onOpenCatalog('All Items', undefined, FEATURED_CREATOR.username)}
                  className="w-full tf-btn-green py-2.5 rounded text-[13.5px] font-semibold cursor-pointer"
                >
                  View {FEATURED_CREATOR.username}&apos;s Portfolio
                </button>
              </div>
            </div>

            {/* 3 Showcase Cards by axiomthemes */}
            <div className="lg:col-span-8 grid grid-cols-1 sm:grid-cols-3 gap-6">
              {creatorItems.map((item) => (
                <ThemeCard
                  key={item.id}
                  item={item}
                  isInCart={cartIds.includes(item.id)}
                  isFavorite={favoriteIds.includes(item.id)}
                  onInspect={onInspect}
                  onLivePreview={onLivePreview}
                  onAddToCart={onAddToCart}
                  onToggleFavorite={onToggleFavorite}
                  onFilterByAuthor={(author) => onOpenCatalog('All Items', undefined, author)}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* 7. "Browse this week's best selling WordPress themes" */}
      <section className="bg-[#F5F5F5] py-14">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-9">
            <div className="space-y-1.5">
              <h2 className="text-[24px] sm:text-[28px] font-bold text-[#262626]">
                Browse this week&apos;s best selling WordPress themes
              </h2>
              <p className="text-[15px] text-[#555555]">
                This week&apos;s best web themes &amp; templates have arrived.
              </p>
            </div>
            <button
              type="button"
              onClick={() => onOpenCatalog('WordPress', 'bestseller')}
              className="tf-btn-green px-5 py-2.5 rounded text-[13.5px] font-semibold inline-flex items-center gap-2 shrink-0 cursor-pointer self-start sm:self-auto"
            >
              <span>View more bestsellers</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {bestsellerItems.map((item) => (
              <ThemeCard
                key={item.id}
                item={item}
                isInCart={cartIds.includes(item.id)}
                isFavorite={favoriteIds.includes(item.id)}
                onInspect={onInspect}
                onLivePreview={onLivePreview}
                onAddToCart={onAddToCart}
                onToggleFavorite={onToggleFavorite}
                onFilterByAuthor={(author) => onOpenCatalog('All Items', undefined, author)}
              />
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
