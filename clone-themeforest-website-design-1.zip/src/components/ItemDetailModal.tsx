import { useState } from 'react';
import {
  X,
  Check,
  Star,
  Eye,
  Heart,
  ShoppingCart,
  ShieldCheck,
  MessageSquare,
  Award,
  ExternalLink,
} from 'lucide-react';
import { ThemeItem } from '../data/marketplaceData';
import { ThemeThumbnail } from './ThemeThumbnail';

interface ItemDetailModalProps {
  item: ThemeItem | null;
  isInCart: boolean;
  isFavorite: boolean;
  onClose: () => void;
  onAddToCart: (item: ThemeItem, license: 'regular' | 'extended', extendSupport: boolean) => void;
  onBuyNow: (item: ThemeItem, license: 'regular' | 'extended', extendSupport: boolean) => void;
  onLivePreview: (item: ThemeItem) => void;
  onToggleFavorite: (item: ThemeItem) => void;
  onFilterByAuthor: (author: string) => void;
}

export function ItemDetailModal({
  item,
  isInCart,
  isFavorite,
  onClose,
  onAddToCart,
  onBuyNow,
  onLivePreview,
  onToggleFavorite,
  onFilterByAuthor,
}: ItemDetailModalProps) {
  const [license, setLicense] = useState<'regular' | 'extended'>('regular');
  const [extendSupport, setExtendSupport] = useState(false);
  const [activeTab, setActiveTab] = useState<'details' | 'reviews' | 'comments'>('details');

  if (!item) return null;

  const basePrice = license === 'regular' ? item.price : item.extendedPrice;
  const totalPrice = +(basePrice + (extendSupport ? item.supportExtendPrice : 0)).toFixed(2);

  return (
    <div
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-[2px] flex items-center justify-center p-2 sm:p-5 overflow-y-auto"
      onClick={onClose}
    >
      <div
        className="bg-[#F5F5F5] w-full max-w-[1080px] max-h-[92vh] rounded-lg shadow-2xl border border-[#DCE1E5] overflow-hidden flex flex-col my-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Header Bar */}
        <div className="bg-white border-b border-[#E1E8ED] px-5 sm:px-7 py-4 flex items-start justify-between gap-4">
          <div className="min-w-0">
            <div className="text-[12px] text-[#777777] flex items-center gap-1.5 flex-wrap">
              <span>Home</span>
              <span>/</span>
              <span>Files</span>
              <span>/</span>
              <span>{item.category}</span>
              <span>/</span>
              <span className="text-[#333333] font-medium">{item.subCategory}</span>
            </div>
            <h2 className="text-[19px] sm:text-[23px] font-bold text-[#262626] leading-snug mt-1">
              {item.title}
            </h2>
            <div className="flex flex-wrap items-center gap-4 mt-2 text-[12.5px] text-[#666666]">
              <span>
                By{' '}
                <button
                  type="button"
                  onClick={() => {
                    onFilterByAuthor(item.author);
                    onClose();
                  }}
                  className="font-bold text-[#0084B4] hover:underline cursor-pointer"
                >
                  {item.author}
                </button>
              </span>
              <span className="inline-flex items-center gap-1 text-amber-800 bg-amber-100/80 px-2 py-0.5 rounded-full text-[11px] font-semibold">
                <Award className="w-3 h-3" />
                {item.authorBadge}
              </span>
              <span className="flex items-center gap-1">
                <ShoppingCart className="w-3.5 h-3.5 text-[#888888]" />
                <strong>{item.sales.toLocaleString()}</strong> sales
              </span>
              <span className="flex items-center gap-1 text-[#262626]">
                <Star className="w-3.5 h-3.5 text-[#F5A623] fill-current" />
                <strong>{item.rating}</strong> ({item.reviewsCount} ratings)
              </span>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Close item details"
            className="p-2 rounded-full hover:bg-[#F5F5F5] text-[#666666] hover:text-[#262626] shrink-0 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="bg-white border-b border-[#E1E8ED] px-5 sm:px-7 flex items-center gap-6 text-[13.5px] font-semibold">
          {[
            { id: 'details', label: 'Item Details' },
            { id: 'reviews', label: `Reviews (${item.reviewsCount})` },
            { id: 'comments', label: 'Comments (142)' },
          ].map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id as 'details' | 'reviews' | 'comments')}
              className={`py-3 border-b-2 transition-colors cursor-pointer ${
                activeTab === tab.id
                  ? 'border-[#82B541] text-[#262626]'
                  : 'border-transparent text-[#666666] hover:text-[#262626]'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Scrollable Content */}
        <div className="p-5 sm:p-7 overflow-y-auto flex-1">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Left Main Column */}
            <div className="lg:col-span-8 space-y-6">
              {activeTab === 'details' && (
                <>
                  {/* Main Preview Box */}
                  <div className="bg-white border border-[#E1E8ED] rounded-md p-3.5 shadow-xs">
                    <div className="aspect-[590/300] w-full rounded overflow-hidden bg-[#F0F2F5] border border-[#EEEEEE]">
                      <ThemeThumbnail item={item} />
                    </div>
                    <div className="mt-3.5 flex flex-wrap items-center justify-center gap-3">
                      <button
                        type="button"
                        onClick={() => onLivePreview(item)}
                        className="bg-[#0084B4] hover:bg-[#00739E] text-white px-5 py-2 rounded text-[13px] font-semibold inline-flex items-center gap-2 shadow-xs cursor-pointer"
                      >
                        <Eye className="w-4 h-4" />
                        <span>Live Preview</span>
                        <ExternalLink className="w-3.5 h-3.5 opacity-80" />
                      </button>

                      <button
                        type="button"
                        onClick={() => onToggleFavorite(item)}
                        className={`px-4 py-2 rounded border text-[13px] font-semibold inline-flex items-center gap-1.5 cursor-pointer transition-colors ${
                          isFavorite
                            ? 'bg-rose-50 border-rose-300 text-rose-600'
                            : 'bg-white border-[#CCCCCC] text-[#555555] hover:border-[#999999]'
                        }`}
                      >
                        <Heart className={`w-4 h-4 ${isFavorite ? 'fill-current' : ''}`} />
                        <span>{isFavorite ? 'Favorited' : 'Add to Favorites'}</span>
                      </button>
                    </div>
                  </div>

                  {/* Description & Features */}
                  <div className="bg-white border border-[#E1E8ED] rounded-md p-6 space-y-5">
                    <div>
                      <h3 className="text-[18px] font-bold text-[#262626] mb-2">
                        About {item.title.split(/[-|]/)[0].trim()}
                      </h3>
                      <p className="text-[14.5px] text-[#444444] leading-relaxed">
                        {item.description}
                      </p>
                    </div>

                    <div className="pt-4 border-t border-[#F0F2F4]">
                      <h4 className="text-[15px] font-bold text-[#262626] mb-3">
                        Key Features &amp; Included Highlights
                      </h4>
                      <ul className="space-y-2">
                        {item.highlights.map((feat, idx) => (
                          <li
                            key={idx}
                            className="flex items-start gap-2.5 text-[14px] text-[#444444]"
                          >
                            <Check className="w-4 h-4 text-[#82B541] shrink-0 mt-0.5 stroke-[2.5]" />
                            <span>{feat}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="pt-4 border-t border-[#F0F2F4]">
                      <h4 className="text-[14px] font-bold text-[#262626] mb-2">
                        Built &amp; Tested Compatibility
                      </h4>
                      <div className="flex flex-wrap gap-2">
                        {item.compatibleWith.map((c) => (
                          <span
                            key={c}
                            className="bg-[#F5F5F5] border border-[#E1E8ED] text-[#444444] text-[12px] font-medium px-2.5 py-1 rounded"
                          >
                            {c}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </>
              )}

              {activeTab === 'reviews' && (
                <div className="bg-white border border-[#E1E8ED] rounded-md p-6 space-y-4">
                  <div className="flex items-center justify-between border-b border-[#EEEEEE] pb-4">
                    <div>
                      <h3 className="text-[18px] font-bold text-[#262626]">
                        Verified Buyer Reviews
                      </h3>
                      <p className="text-[13px] text-[#666666]">
                        {item.rating} average based on {item.reviewsCount} customer ratings
                      </p>
                    </div>
                    <div className="flex items-center gap-1 text-[#F5A623]">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <Star key={i} className="w-5 h-5 fill-current" />
                      ))}
                    </div>
                  </div>

                  {[
                    {
                      user: 'marcus_webstudio',
                      reason: 'Design Quality',
                      comment:
                        'Cleanest codebase and fastest demo import I have used this year. PageSpeed hit 97 on mobile right after configuring images.',
                      date: '3 days ago',
                    },
                    {
                      user: 'elena_digital',
                      reason: 'Customer Support',
                      comment:
                        'Had a small header customization question and the author team replied in under 2 hours with a working CSS snippet. Well worth every dollar!',
                      date: '1 week ago',
                    },
                    {
                      user: 'agency_north',
                      reason: 'Flexibility',
                      comment:
                        'We have deployed this theme across 4 client websites already. Documentation is crystal clear and updates never break child layouts.',
                      date: '2 weeks ago',
                    },
                  ].map((rev) => (
                    <div
                      key={rev.user}
                      className="border border-[#E6E9EC] rounded p-4 space-y-2 bg-[#FAFAFA]"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="flex text-[#F5A623]">
                            {Array.from({ length: 5 }).map((_, i) => (
                              <Star key={i} className="w-3.5 h-3.5 fill-current" />
                            ))}
                          </div>
                          <span className="text-[13px] font-bold text-[#262626]">
                            for {rev.reason}
                          </span>
                        </div>
                        <span className="text-[12px] text-[#888888]">{rev.date}</span>
                      </div>
                      <p className="text-[13.5px] text-[#444444] leading-relaxed">
                        {rev.comment}
                      </p>
                      <div className="text-[12px] text-[#777777]">
                        by <span className="font-semibold text-[#555555]">{rev.user}</span> ·{' '}
                        <span className="text-[#6F9A37]">Verified Buyer</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {activeTab === 'comments' && (
                <div className="bg-white border border-[#E1E8ED] rounded-md p-6 space-y-4">
                  <h3 className="text-[18px] font-bold text-[#262626] flex items-center gap-2">
                    <MessageSquare className="w-5 h-5 text-[#82B541]" />
                    Pre-Sale Questions &amp; Author Replies
                  </h3>
                  {[
                    {
                      author: 'alex_dev88',
                      q: `Does ${item.title.split(' ')[0]} include all demo images and Figma/design assets out of the box?`,
                      a: `Hi there! Yes, 100% of demo layouts and placeholder structures import in one click, and our ${item.softwareVersion} package includes full step-by-step documentation.`,
                    },
                    {
                      author: 'sophie_commerce',
                      q: 'Is RTL and multi-language translation with WPML / Polylang supported?',
                      a: 'Absolutely! Full RTL stylesheets and .pot translation files are bundled directly in the theme package.',
                    },
                  ].map((thread, i) => (
                    <div key={i} className="border border-[#E6E9EC] rounded p-4 space-y-3">
                      <div>
                        <span className="text-[12px] font-bold text-[#262626]">{thread.author}</span>
                        <p className="text-[13.5px] text-[#444444] mt-1">{thread.q}</p>
                      </div>
                      <div className="bg-[#F5F8F2] border-l-2 border-[#82B541] p-3 rounded-r">
                        <div className="flex items-center gap-2">
                          <span className="text-[12px] font-bold text-[#262626]">
                            {item.author}
                          </span>
                          <span className="text-[10px] font-bold bg-[#82B541] text-white px-1.5 py-0.2 rounded">
                            AUTHOR
                          </span>
                        </div>
                        <p className="text-[13px] text-[#444444] mt-1">{thread.a}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Right Purchase & Metadata Sidebar */}
            <div className="lg:col-span-4 space-y-5">
              {/* Purchase License Box */}
              <div className="bg-white border border-[#E1E8ED] rounded-md p-5 shadow-xs space-y-4">
                <div className="flex items-center justify-between border-b border-[#EEEEEE] pb-3">
                  <select
                    value={license}
                    onChange={(e) => setLicense(e.target.value as 'regular' | 'extended')}
                    aria-label="Select license type"
                    className="font-bold text-[15px] text-[#262626] bg-transparent focus:outline-none cursor-pointer"
                  >
                    <option value="regular">Regular License</option>
                    <option value="extended">Extended License</option>
                  </select>
                  <div className="text-[26px] font-extrabold text-[#262626]">
                    ${totalPrice}
                  </div>
                </div>

                <p className="text-[12px] text-[#666666] leading-relaxed">
                  {license === 'regular'
                    ? 'Use, by you or one client, in a single end product which end users are not charged for.'
                    : 'Use, by you or one client, in a single end product which end users can be charged for.'}
                </p>

                <ul className="space-y-2 text-[13px] text-[#444444]">
                  <li className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-[#82B541]" />
                    <span>Quality checked by Envato</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-[#82B541]" />
                    <span>Future updates included</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-[#82B541]" />
                    <span>6 months support from {item.author}</span>
                  </li>
                </ul>

                <label className="flex items-start gap-2.5 pt-2 border-t border-[#F0F2F4] cursor-pointer text-[13px]">
                  <input
                    type="checkbox"
                    checked={extendSupport}
                    onChange={(e) => setExtendSupport(e.target.checked)}
                    className="mt-1 accent-[#82B541]"
                  />
                  <span className="flex-1 text-[#444444]">
                    Extend support to 12 months
                    <span className="font-bold text-[#262626] ml-1.5">
                      +${item.supportExtendPrice.toFixed(2)}
                    </span>
                  </span>
                </label>

                <div className="space-y-2.5 pt-1">
                  <button
                    type="button"
                    onClick={() => onAddToCart(item, license, extendSupport)}
                    className="w-full tf-btn-green py-3 rounded font-bold text-[14px] flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <ShoppingCart className="w-4 h-4" />
                    <span>{isInCart ? 'Added to Cart — View Cart' : 'Add to Cart'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => onBuyNow(item, license, extendSupport)}
                    className="w-full bg-[#333333] hover:bg-[#262626] text-white py-2.5 rounded font-semibold text-[13.5px] transition-colors cursor-pointer"
                  >
                    Buy Now · ${totalPrice}
                  </button>
                </div>

                <div className="text-[11px] text-[#888888] text-center flex items-center justify-center gap-1 pt-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-[#82B541]" />
                  <span>Price is in US dollars and excludes tax and handling fees</span>
                </div>
              </div>

              {/* Technical Attributes Table */}
              <div className="bg-white border border-[#E1E8ED] rounded-md p-5 text-[12.5px]">
                <h4 className="font-bold text-[14px] text-[#262626] mb-3 pb-2 border-b border-[#EEEEEE]">
                  Item Attributes
                </h4>
                <dl className="space-y-2.5">
                  <div className="flex justify-between gap-3">
                    <dt className="font-semibold text-[#555555]">Last Update</dt>
                    <dd className="text-[#333333] text-right">{item.lastUpdated}</dd>
                  </div>
                  <div className="flex justify-between gap-3">
                    <dt className="font-semibold text-[#555555]">Published</dt>
                    <dd className="text-[#333333] text-right">{item.published}</dd>
                  </div>
                  <div className="flex justify-between gap-3">
                    <dt className="font-semibold text-[#555555]">High Resolution</dt>
                    <dd className="text-[#333333] text-right">Yes</dd>
                  </div>
                  <div className="flex justify-between gap-3">
                    <dt className="font-semibold text-[#555555]">Software Version</dt>
                    <dd className="text-[#0084B4] text-right font-medium">
                      {item.softwareVersion}
                    </dd>
                  </div>
                  <div className="flex justify-between gap-3">
                    <dt className="font-semibold text-[#555555]">Files Included</dt>
                    <dd className="text-[#333333] text-right">
                      {item.filesIncluded.join(', ')}
                    </dd>
                  </div>
                  <div className="flex justify-between gap-3">
                    <dt className="font-semibold text-[#555555]">Columns</dt>
                    <dd className="text-[#333333] text-right">{item.columns}</dd>
                  </div>
                  <div className="flex justify-between gap-3">
                    <dt className="font-semibold text-[#555555]">Documentation</dt>
                    <dd className="text-[#333333] text-right">Well Documented</dd>
                  </div>
                  <div className="flex justify-between gap-3">
                    <dt className="font-semibold text-[#555555]">Layout</dt>
                    <dd className="text-[#333333] text-right">{item.layout}</dd>
                  </div>
                </dl>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
