import { CATEGORY_TILES, CategoryTile, MainCategory } from '../data/marketplaceData';
import { CategoryIconBadge } from './EnvatoLogo';

interface CategoryTilesProps {
  onSelectCategory: (cat: MainCategory, sort?: 'newest' | 'bestseller') => void;
}

export function CategoryTiles({ onSelectCategory }: CategoryTilesProps) {
  return (
    <section className="bg-[#F5F5F5] pb-14 pt-2">
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {CATEGORY_TILES.map((tile) => (
            <CategoryCard key={tile.id} tile={tile} onSelectCategory={onSelectCategory} />
          ))}
        </div>
      </div>
    </section>
  );
}

function CategoryCard({
  tile,
  onSelectCategory,
}: {
  tile: CategoryTile;
  onSelectCategory: (cat: MainCategory, sort?: 'newest' | 'bestseller') => void;
}) {
  return (
    <div
      onClick={() => onSelectCategory(tile.filterCategory)}
      className="tf-category-tile flex flex-col justify-between pt-7 px-6 pb-0 overflow-hidden cursor-pointer group"
    >
      {/* Top Text & Quick Filter Links */}
      <div className="text-center space-y-1.5 mb-5">
        <h2 className="text-[20px] font-bold text-[#262626] group-hover:text-[#0084B4] transition-colors">
          {tile.title}
        </h2>
        <p className="text-[13.5px] text-[#666666] leading-snug min-h-[20px]">
          {tile.subtitle}
        </p>
        <div className="pt-1 flex items-center justify-center gap-3 text-[13px] font-medium">
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onSelectCategory(tile.filterCategory, 'newest');
            }}
            className="text-[#0084B4] hover:underline cursor-pointer"
          >
            Newest
          </button>
          <span className="text-[#CCCCCC]">·</span>
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onSelectCategory(tile.filterCategory, 'bestseller');
            }}
            className="text-[#0084B4] hover:underline cursor-pointer"
          >
            Bestsellers
          </button>
        </div>
      </div>

      {/* Bottom Tilted Dual-Thumbnail Collage + Floating Circular Category Badge */}
      <div
        className="relative h-[148px] mx-auto w-full rounded-t-lg pt-6 px-4 flex items-end justify-center overflow-hidden transition-colors"
        style={{ backgroundColor: tile.bgTint }}
      >
        {/* Floating Category Icon Badge */}
        <div className="absolute top-3 left-1/2 -translate-x-1/2 z-20 group-hover:scale-110 transition-transform duration-300">
          <CategoryIconBadge type={tile.iconType} />
        </div>

        {/* Left Angled Mini Browser Card */}
        <div className="w-[54%] h-[106px] bg-white rounded-t-md shadow-md border border-black/10 -rotate-3 translate-y-2 -mr-4 p-2 flex flex-col justify-between transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:-rotate-2">
          <div className="flex items-center gap-1 border-b border-neutral-100 pb-1">
            <span className="w-1.5 h-1.5 rounded-full bg-neutral-300" />
            <span className="w-1.5 h-1.5 rounded-full bg-neutral-300" />
            <span className="text-[8px] font-bold text-neutral-500 truncate ml-1">
              {tile.previewTheme1}
            </span>
          </div>
          <div
            className="h-9 rounded-sm opacity-90 flex items-center px-2"
            style={{ backgroundColor: tile.accentColor }}
          >
            <div className="w-10 h-1.5 bg-white/80 rounded-full" />
          </div>
          <div className="grid grid-cols-3 gap-1">
            <div className="h-4 bg-neutral-100 rounded-sm" />
            <div className="h-4 bg-neutral-100 rounded-sm" />
            <div className="h-4 bg-neutral-100 rounded-sm" />
          </div>
        </div>

        {/* Right Angled Mini Browser Card */}
        <div className="w-[54%] h-[116px] bg-white rounded-t-md shadow-lg border border-black/10 rotate-2 translate-y-1 z-10 p-2 flex flex-col justify-between transition-transform duration-300 group-hover:translate-y-0 group-hover:rotate-1">
          <div className="flex items-center justify-between border-b border-neutral-100 pb-1">
            <span className="text-[8px] font-bold text-neutral-700 truncate">
              {tile.previewTheme2}
            </span>
            <span
              className="text-[7px] font-bold text-white px-1 rounded"
              style={{ backgroundColor: tile.accentColor }}
            >
              PRO
            </span>
          </div>
          <div className="grid grid-cols-2 gap-1.5 flex-1 pt-1.5">
            <div className="bg-neutral-50 border border-neutral-100 rounded p-1 flex flex-col justify-between">
              <div
                className="h-7 rounded-sm opacity-25"
                style={{ backgroundColor: tile.accentColor }}
              />
              <div className="h-1.5 w-3/4 bg-neutral-200 rounded" />
            </div>
            <div className="bg-neutral-50 border border-neutral-100 rounded p-1 flex flex-col justify-between">
              <div className="h-7 rounded-sm bg-neutral-200/70" />
              <div className="h-1.5 w-2/3 bg-neutral-200 rounded" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
