import { EnvatoMarketWordmark } from './EnvatoLogo';

interface FooterProps {
  onGoHome: () => void;
  onShowToast: (msg: string) => void;
}

const FOOTER_COLUMNS = [
  {
    heading: 'ENVATO MARKET',
    links: [
      'Terms',
      'Licenses',
      'Market API',
      'Become an affiliate',
      'Cookies',
      'Cookie Settings',
    ],
  },
  {
    heading: 'HELP',
    links: ['Help Center', 'Authors'],
  },
  {
    heading: 'OUR COMMUNITY',
    links: ['Community', 'Blog', 'Forums', 'Meetups'],
  },
  {
    heading: 'MEET ENVATO',
    links: [
      'About Envato',
      'Careers',
      'Privacy Policy',
      'Do not sell or share my personal information',
      'Sitemap',
    ],
  },
];

export function Footer({ onGoHome, onShowToast }: FooterProps) {
  return (
    <footer className="bg-[#262626] text-[#999999] text-[13px]">
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 pt-12 pb-10">
        {/* Top Brand + Marketplace Stats Row */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-9 border-b border-[#383838]">
          <button
            type="button"
            onClick={onGoHome}
            className="text-left focus:outline-none cursor-pointer self-start"
          >
            <EnvatoMarketWordmark size="lg" />
          </button>

          <div className="flex flex-wrap items-center gap-8 sm:gap-12">
            <div>
              <div className="text-[20px] sm:text-[22px] font-bold text-white leading-tight">
                76,320,894
              </div>
              <div className="text-[12px] text-[#8E8E8E]">items sold</div>
            </div>
            <div>
              <div className="text-[20px] sm:text-[22px] font-bold text-white leading-tight">
                $1,192,482,910
              </div>
              <div className="text-[12px] text-[#8E8E8E]">community earnings</div>
            </div>
          </div>
        </div>

        {/* 4 Columns + B-Corp Certification Badge */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-12 gap-8 py-10">
          {FOOTER_COLUMNS.map((col) => (
            <div key={col.heading} className="lg:col-span-2 space-y-3">
              <h4 className="text-[11px] font-bold uppercase tracking-wider text-[#CCCCCC]">
                {col.heading}
              </h4>
              <ul className="space-y-2">
                {col.links.map((label) => (
                  <li key={label}>
                    <button
                      type="button"
                      onClick={() => onShowToast(`${col.heading}: ${label}`)}
                      className="text-left text-[13px] text-[#999999] hover:text-white transition-colors cursor-pointer"
                    >
                      {label}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          ))}

          {/* Right B-Corp & Ecosystem Note */}
          <div className="col-span-2 sm:col-span-4 lg:col-span-4 flex flex-col sm:flex-row lg:flex-col items-start lg:items-end justify-between gap-4 lg:text-right">
            <div className="inline-flex items-center gap-3 bg-[#1E1E1E] border border-[#383838] rounded-md px-4 py-3">
              <div className="w-10 h-10 rounded-full border-2 border-white text-white font-black text-[18px] flex items-center justify-center shrink-0">
                B
              </div>
              <div className="text-left">
                <div className="text-[12px] font-bold text-white">Certified B Corporation</div>
                <div className="text-[11px] text-[#999999]">
                  Verified social &amp; environmental standards
                </div>
              </div>
            </div>
            <p className="text-[12.5px] text-[#8E8E8E] max-w-[300px]">
              All the assets you need, in one place. Powering websites for agencies, developers, and creators globally.
            </p>
          </div>
        </div>
      </div>

      {/* Bottom Legal & Social Strip */}
      <div className="bg-[#1A1A1A] border-t border-[#2E2E2E]">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6 py-5 flex flex-col sm:flex-row items-center justify-between gap-4 text-[12px] text-[#808080]">
          <div className="text-center sm:text-left">
            <div className="text-[#9E9E9E]">
              Envato.com · Envato Elements · Envato Market · Envato Tuts+ · Placeit by Envato
            </div>
            <div className="mt-1">
              © 2026 Envato Pty Ltd. Trademarks and brands are the property of their respective owners.
            </div>
          </div>

          <div className="flex items-center gap-3">
            {['YouTube', 'X', 'Facebook', 'Instagram', 'Pinterest'].map((social) => (
              <button
                key={social}
                type="button"
                onClick={() => onShowToast(`Envato on ${social}`)}
                className="px-2.5 py-1 rounded bg-[#262626] hover:bg-[#333333] text-[#AAAAAA] hover:text-white text-[11px] font-medium transition-colors cursor-pointer"
              >
                {social}
              </button>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
