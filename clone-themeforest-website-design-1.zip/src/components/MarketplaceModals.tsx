import React, { useState } from 'react';
import {
  X,
  Heart,
  ShoppingCart,
  Eye,
  Sparkles,
  Check,
  Lock,
} from 'lucide-react';
import { ThemeItem } from '../data/marketplaceData';
import { EnvatoMarketWordmark } from './EnvatoLogo';
import { ThemeThumbnail } from './ThemeThumbnail';

/* ---------------- Favorites Drawer ---------------- */
interface FavoritesDrawerProps {
  isOpen: boolean;
  items: ThemeItem[];
  cartIds: number[];
  onClose: () => void;
  onRemoveFavorite: (item: ThemeItem) => void;
  onAddToCart: (item: ThemeItem) => void;
  onInspect: (item: ThemeItem) => void;
  onLivePreview: (item: ThemeItem) => void;
}

export function FavoritesDrawer({
  isOpen,
  items,
  cartIds,
  onClose,
  onRemoveFavorite,
  onAddToCart,
  onInspect,
  onLivePreview,
}: FavoritesDrawerProps) {
  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 bg-black/50 backdrop-blur-[1px] flex justify-end"
      onClick={onClose}
    >
      <div
        className="w-full max-w-[430px] bg-white h-full shadow-2xl flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="bg-[#262626] text-white px-5 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Heart className="w-5 h-5 text-rose-400 fill-current" />
            <h2 className="text-[17px] font-bold">Saved Favorites ({items.length})</h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded hover:bg-[#383838] text-[#CCCCCC] hover:text-white cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-5 bg-[#F5F5F5] space-y-3">
          {items.length === 0 ? (
            <div className="bg-white border border-[#E1E8ED] rounded-lg p-8 text-center space-y-2 my-8">
              <Heart className="w-9 h-9 text-[#CCCCCC] mx-auto" />
              <h3 className="text-[16px] font-bold text-[#262626]">No favorites saved yet</h3>
              <p className="text-[13px] text-[#666666]">
                Click the heart icon on any theme card to shortlist items for your projects.
              </p>
            </div>
          ) : (
            items.map((item) => {
              const inCart = cartIds.includes(item.id);
              return (
                <div
                  key={item.id}
                  className="bg-white border border-[#E1E8ED] rounded-md p-3.5 space-y-2.5"
                >
                  <div className="flex gap-3">
                    <div
                      onClick={() => {
                        onClose();
                        onInspect(item);
                      }}
                      className="w-24 aspect-[590/300] rounded overflow-hidden border border-[#EEEEEE] shrink-0 cursor-pointer"
                    >
                      <ThemeThumbnail item={item} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4
                        onClick={() => {
                          onClose();
                          onInspect(item);
                        }}
                        className="text-[13.5px] font-bold text-[#262626] hover:text-[#0084B4] line-clamp-2 cursor-pointer"
                      >
                        {item.title}
                      </h4>
                      <div className="flex items-center justify-between mt-1">
                        <span className="text-[12px] text-[#777777]">by {item.author}</span>
                        <span className="text-[15px] font-extrabold text-[#262626]">
                          ${item.price}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 pt-2 border-t border-[#F0F2F4]">
                    <button
                      type="button"
                      onClick={() => onAddToCart(item)}
                      className="flex-1 tf-btn-green py-1.5 rounded text-[12px] font-semibold inline-flex items-center justify-center gap-1 cursor-pointer"
                    >
                      <ShoppingCart className="w-3.5 h-3.5" />
                      <span>{inCart ? 'In Cart' : 'Add to Cart'}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        onClose();
                        onLivePreview(item);
                      }}
                      className="px-3 py-1.5 rounded border border-[#CCCCCC] hover:border-[#0084B4] text-[12px] font-medium inline-flex items-center gap-1 cursor-pointer"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>Preview</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => onRemoveFavorite(item)}
                      className="px-2.5 py-1.5 rounded border border-[#E1E8ED] text-rose-500 hover:bg-rose-50 text-[12px] cursor-pointer"
                      title="Remove from favorites"
                    >
                      Remove
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}

/* ---------------- Auth Sign In Modal ---------------- */
interface AuthModalProps {
  isOpen: boolean;
  signedInUser: string | null;
  onClose: () => void;
  onSignIn: (username: string) => void;
  onSignOut: () => void;
}

export function AuthModal({
  isOpen,
  signedInUser,
  onClose,
  onSignIn,
  onSignOut,
}: AuthModalProps) {
  const [username, setUsername] = useState('alex.designer');
  const [password, setPassword] = useState('••••••••••••');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (username.trim()) {
      onSignIn(username.trim());
      onClose();
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-[2px] flex items-center justify-center p-4"
      onClick={onClose}
    >
      <div
        className="bg-white w-full max-w-[420px] rounded-lg shadow-2xl border border-[#DCE1E5] overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="bg-[#262626] px-6 py-4 flex items-center justify-between">
          <EnvatoMarketWordmark size="md" />
          <button
            type="button"
            onClick={onClose}
            className="text-[#AAAAAA] hover:text-white cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {signedInUser ? (
          <div className="p-6 text-center space-y-4">
            <div className="w-14 h-14 rounded-full bg-[#82B541]/15 text-[#6F9A37] font-extrabold text-[20px] flex items-center justify-center mx-auto">
              {signedInUser.slice(0, 2).toUpperCase()}
            </div>
            <div>
              <h3 className="text-[18px] font-bold text-[#262626]">
                Signed in as {signedInUser}
              </h3>
              <p className="text-[13px] text-[#666666] mt-1">
                Envato Market Account · Buyer &amp; Creator Ready
              </p>
            </div>
            <div className="flex gap-3 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 tf-btn-green py-2.5 rounded text-[13px] font-semibold cursor-pointer"
              >
                Continue Browsing
              </button>
              <button
                type="button"
                onClick={() => {
                  onSignOut();
                  onClose();
                }}
                className="px-4 py-2.5 rounded border border-[#CCCCCC] text-[13px] font-semibold text-[#555555] hover:bg-[#F5F5F5] cursor-pointer"
              >
                Sign Out
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 space-y-4">
            <div>
              <h3 className="text-[19px] font-bold text-[#262626]">
                Great to have you back!
              </h3>
              <p className="text-[13px] text-[#666666] mt-0.5">
                Sign in with your Envato Account to manage purchases, favorites &amp; licenses.
              </p>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-[12px] font-semibold text-[#444444] mb-1">
                  Username or Email
                </label>
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  required
                  className="w-full px-3 py-2 border border-[#DCE1E5] rounded text-[14px] focus:outline-none focus:border-[#82B541]"
                />
              </div>
              <div>
                <label className="block text-[12px] font-semibold text-[#444444] mb-1">
                  Password
                </label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="w-full px-3 py-2 border border-[#DCE1E5] rounded text-[14px] focus:outline-none focus:border-[#82B541]"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full tf-btn-green py-2.5 rounded font-bold text-[14px] flex items-center justify-center gap-2 cursor-pointer"
            >
              <Lock className="w-4 h-4" />
              <span>Sign in to Envato</span>
            </button>

            <p className="text-[11.5px] text-center text-[#888888]">
              One account gives you access to ThemeForest, CodeCanyon, VideoHive &amp; Elements.
            </p>
          </form>
        )}
      </div>
    </div>
  );
}

/* ---------------- Envato Elements Unlimited Modal ---------------- */
export function ElementsModal({
  isOpen,
  onClose,
  onShowToast,
}: {
  isOpen: boolean;
  onClose: () => void;
  onShowToast: (msg: string) => void;
}) {
  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-[2px] flex items-center justify-center p-4"
      onClick={onClose}
    >
      <div
        className="bg-white w-full max-w-[680px] rounded-xl shadow-2xl border border-[#DCE1E5] overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="bg-[#262626] text-white p-6 flex items-start justify-between gap-4">
          <div className="space-y-1.5">
            <span className="inline-flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-[#82B541]">
              <Sparkles className="w-3.5 h-3.5" />
              Envato Elements Subscription
            </span>
            <h3 className="text-[22px] sm:text-[25px] font-extrabold leading-tight">
              Unlimited downloads across 19+ million creative assets
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-[#AAAAAA] hover:text-white cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="border border-[#E1E8ED] rounded-lg p-4 space-y-2.5 bg-[#FAFAFA]">
              <div className="text-[12px] font-bold uppercase tracking-wider text-[#777777]">
                ThemeForest Marketplace
              </div>
              <div className="text-[20px] font-extrabold text-[#262626]">
                Pay per item ($19–$119)
              </div>
              <ul className="space-y-1.5 text-[13px] text-[#555555]">
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-[#82B541]" />
                  Flagship themes like Avada, WoodMart &amp; Flatsome
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-[#82B541]" />
                  6–12 months dedicated author support
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-[#82B541]" />
                  Lifetime item updates on single project
                </li>
              </ul>
            </div>

            <div className="border-2 border-[#82B541] rounded-lg p-4 space-y-2.5 bg-[#F8FCF4]">
              <div className="text-[12px] font-bold uppercase tracking-wider text-[#5C832C]">
                Envato Elements
              </div>
              <div className="text-[20px] font-extrabold text-[#262626]">
                From $16.50 / month
              </div>
              <ul className="space-y-1.5 text-[13px] text-[#444444]">
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-[#82B541]" />
                  Unlimited WordPress kits, HTML, Figma &amp; UI
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-[#82B541]" />
                  Stock Video, Audio, Photos &amp; 3D included
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-[#82B541]" />
                  Built-in AI Image &amp; Asset generation tools
                </li>
              </ul>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-end gap-3 pt-2 border-t border-[#EEEEEE]">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded border border-[#CCCCCC] text-[13px] font-semibold text-[#555555] hover:bg-[#F5F5F5] cursor-pointer"
            >
              Stay on ThemeForest
            </button>
            <button
              type="button"
              onClick={() => {
                onClose();
                onShowToast('Envato Elements 7-Day Commercial Trial ready!');
              }}
              className="tf-btn-green px-6 py-2.5 rounded text-[13.5px] font-bold cursor-pointer"
            >
              Get Unlimited Downloads
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
