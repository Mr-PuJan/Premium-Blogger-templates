export function EnvatoLeafIcon({ className = 'w-5 h-5' }: { className?: string }) {
  return (
    <svg viewBox="0 0 28 32" fill="none" className={className} aria-hidden="true">
      <path
        d="M23.6 1.8C19.8-.2 10.6 3.1 5.3 11.4 1.8 16.9 1.7 23.6 4.7 27.6c3.1 4.1 8.9 5.3 13.9 2.7 6-3.1 8.8-10.7 8.4-19.3-.2-5.3-.9-7.9-3.4-9.2z"
        fill="#82B541"
      />
      <path
        d="M8.5 23.5c2.2-5.1 6.7-9.8 11.8-12.5-3.4 4.1-6.5 9.1-8.1 14.3-.4 1.3-2.9.6-3.7-1.8z"
        fill="#FFFFFF"
        fillOpacity="0.22"
      />
    </svg>
  );
}

export function EnvatoMarketWordmark({
  size = 'md',
}: {
  size?: 'sm' | 'md' | 'lg';
}) {
  const sizes = {
    sm: { icon: 'w-4 h-4', text: 'text-[17px]' },
    md: { icon: 'w-[18px] h-[20px]', text: 'text-[20px]' },
    lg: { icon: 'w-6 h-6', text: 'text-[24px]' },
  }[size];

  return (
    <span className="inline-flex items-center gap-1.5 select-none">
      <EnvatoLeafIcon className={sizes.icon} />
      <span className={`${sizes.text} tracking-tight leading-none`}>
        <span className="font-bold text-white">envato</span>
        <span className="font-normal text-[#C2C2C2] ml-0.5">market</span>
      </span>
    </span>
  );
}

export function CategoryIconBadge({
  type,
}: {
  type: 'wordpress' | 'ecommerce' | 'site' | 'marketing' | 'cms' | 'blogging';
}) {
  switch (type) {
    case 'wordpress':
      return (
        <div className="w-12 h-12 rounded-full bg-[#21759B] border-[3px] border-white shadow-md flex items-center justify-center text-white">
          <svg viewBox="0 0 24 24" className="w-6 h-6" fill="currentColor">
            <path d="M12 2C6.49 2 2 6.49 2 12s4.49 10 10 10 10-4.49 10-10S17.51 2 12 2zm-8.4 10c0-1.26.29-2.45.8-3.52l4.4 12.06A8.4 8.4 0 013.6 12zm8.4 8.4c-.82 0-1.61-.12-2.36-.34l2.51-7.28 2.57 7.04c.02.04.04.08.07.11-.87.3-1.81.47-2.79.47zm1.16-12.33c.5-.03.95-.08.95-.08.45-.05.4-.71-.05-.68 0 0-1.35.11-2.22.11-.82 0-2.19-.11-2.19-.11-.45-.03-.5.66-.05.68 0 0 .42.05.87.08l1.29 3.54-1.82 5.45-3.02-8.99c.5-.03.95-.08.95-.08.45-.05.39-.71-.05-.68 0 0-1.35.11-2.22.11-.16 0-.34 0-.53-.01A8.38 8.38 0 0112 3.6c2.19 0 4.18.84 5.68 2.21-.04 0-.07-.01-.11-.01-.82 0-1.4.71-1.4 1.48 0 .68.39 1.26.82 1.95.32.55.68 1.26.68 2.29 0 .71-.27 1.54-.63 2.69l-.83 2.77-3.05-9.01zm5.92.62c.39.92.61 1.94.61 3.01 0 2.97-1.56 5.58-3.91 7.06l2.4-6.95c.45-1.12.6-2.01.6-2.81 0-.29-.02-.56-.06-.81.12.16.24.33.36.5z" />
          </svg>
        </div>
      );
    case 'ecommerce':
      return (
        <div className="w-12 h-12 rounded-full bg-[#7AB55C] border-[3px] border-white shadow-md flex items-center justify-center text-white">
          <svg viewBox="0 0 24 24" className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z" />
            <path d="M3 6h18" />
            <path d="M16 10a4 4 0 0 1-8 0" />
          </svg>
        </div>
      );
    case 'site':
      return (
        <div className="w-12 h-12 rounded-full bg-[#E34F26] border-[3px] border-white shadow-md flex items-center justify-center text-white">
          <svg viewBox="0 0 24 24" className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
            <polyline points="16 18 22 12 16 6" />
            <polyline points="8 6 2 12 8 18" />
          </svg>
        </div>
      );
    case 'marketing':
      return (
        <div className="w-12 h-12 rounded-full bg-[#0099D5] border-[3px] border-white shadow-md flex items-center justify-center text-white">
          <svg viewBox="0 0 24 24" className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2.1" strokeLinecap="round" strokeLinejoin="round">
            <path d="M3 11l18-5v12L3 14v-3z" />
            <path d="M11.6 16.8a3 3 0 1 1-5.8-1.6" />
          </svg>
        </div>
      );
    case 'cms':
      return (
        <div className="w-12 h-12 rounded-full bg-[#6C5CE7] border-[3px] border-white shadow-md flex items-center justify-center text-white">
          <svg viewBox="0 0 24 24" className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2.1" strokeLinecap="round" strokeLinejoin="round">
            <polygon points="12 2 2 7 12 12 22 7 12 2" />
            <polyline points="2 17 12 22 22 17" />
            <polyline points="2 12 12 17 22 12" />
          </svg>
        </div>
      );
    case 'blogging':
      return (
        <div className="w-12 h-12 rounded-full bg-[#F57D00] border-[3px] border-white shadow-md flex items-center justify-center text-white">
          <svg viewBox="0 0 24 24" className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2.1" strokeLinecap="round" strokeLinejoin="round">
            <path d="M12 20h9" />
            <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z" />
          </svg>
        </div>
      );
  }
}
