import { ShoppingCart, Heart, Star, Check, Eye } from 'lucide-react';
import { ThemeItem } from '../data/marketplaceData';
import { ThemeThumbnail } from './ThemeThumbnail';

interface ThemeCardProps {
  item: ThemeItem;
  isInCart: boolean;
  isFavorite: boolean;
  onInspect: (item: ThemeItem) => void;
  onLivePreview: (item: ThemeItem) => void;
  onAddToCart: (item: ThemeItem) => void;
  onToggleFavorite: (item: ThemeItem) => void;
  onFilterByAuthor?: (author: string) => void;
}

export function ThemeCard({
  item,
  isInCart,
  isFavorite,
  onInspect,
  onLivePreview,
  onAddToCart,
  onToggleFavorite,
  onFilterByAuthor,
}: ThemeCardProps) {
  return (
    <article className="tf-card flex flex-col overflow-hidden group">
      {/* 590x300 (approx 2:1) Preview Thumbnail */}
      <div
        onClick={() => onInspect(item)}
        className="relative aspect-[590/300] w-full bg-[#F0F2F5] overflow-hidden cursor-pointer border-b border-[#EEF0F2]"
      >
        <ThemeThumbnail
          item={item}
          className="transition-transform duration-300 group-hover:scale-[1.025]"
        />

        {/* Subtle Hover Action Pill + Favorite Heart */}
        <div className="absolute top-2 right-2 flex items-center gap-1.5 z-10">
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onToggleFavorite(item);
            }}
            aria-label={isFavorite ? 'Remove from favorites' : 'Add to favorites'}
            className={`w-7 h-7 rounded-full shadow-md flex items-center justify-center transition-all cursor-pointer ${
              isFavorite
                ? 'bg-rose-500 text-white'
                : 'bg-white/95 text-[#666666] hover:text-rose-500 opacity-0 group-hover:opacity-100'
            }`}
          >
            <Heart className={`w-3.5 h-3.5 ${isFavorite ? 'fill-current' : ''}`} />
          </button>
        </div>

        {/* Bottom-left Quick Tag on Hover */}
        <div className="absolute bottom-2 left-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none">
          <span className="bg-[#262626]/85 backdrop-blur-sm text-white text-[10.5px] font-medium px-2 py-0.5 rounded">
            {item.platformTags[0]} · {item.subCategory}
          </span>
        </div>
      </div>

      {/* Card Body */}
      <div className="p-3.5 flex-1 flex flex-col justify-between gap-3">
        <div>
          <h3
            onClick={() => onInspect(item)}
            className="text-[14px] font-bold text-[#333333] hover:text-[#0084B4] leading-[1.35] line-clamp-1 cursor-pointer transition-colors"
            title={item.title}
          >
            {item.title}
          </h3>
          <p className="text-[12px] text-[#777777] mt-0.5 truncate">
            <span>by </span>
            <button
              type="button"
              onClick={() => onFilterByAuthor?.(item.author)}
              className="font-semibold text-[#666666] hover:text-[#262626] hover:underline cursor-pointer"
            >
              {item.author}
            </button>
            <span> in </span>
            <span className="text-[#666666]">{item.subCategory}</span>
          </p>
        </div>

        {/* Price + Ratings + Sales + Action Buttons */}
        <div className="flex items-end justify-between gap-2 pt-1">
          <div className="min-w-0">
            <div className="text-[17px] font-extrabold text-[#262626] leading-none">
              ${item.price}
            </div>
            <div className="flex items-center gap-1 mt-1.5">
              <div className="flex items-center text-[#F5A623]">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className="w-3 h-3 fill-current" />
                ))}
              </div>
              <span className="text-[11px] text-[#777777] font-medium">
                ({item.reviewsCount})
              </span>
            </div>
            <div className="text-[11px] text-[#888888] mt-0.5">
              {item.salesFormatted}
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <button
              type="button"
              onClick={() => onAddToCart(item)}
              title={isInCart ? 'In Cart — Click to view cart' : 'Add to Cart'}
              className={`h-[30px] w-[32px] rounded border flex items-center justify-center transition-colors cursor-pointer ${
                isInCart
                  ? 'bg-[#82B541] border-[#6F9A37] text-white'
                  : 'bg-white border-[#CCCCCC] text-[#555555] hover:border-[#82B541] hover:text-[#6F9A37]'
              }`}
            >
              {isInCart ? (
                <Check className="w-3.5 h-3.5 stroke-[2.5]" />
              ) : (
                <ShoppingCart className="w-3.5 h-3.5" />
              )}
            </button>
            <button
              type="button"
              onClick={() => onLivePreview(item)}
              className="h-[30px] px-2.5 rounded border border-[#CCCCCC] bg-white hover:border-[#0084B4] hover:text-[#0084B4] text-[#555555] text-[12px] font-medium inline-flex items-center gap-1 transition-colors cursor-pointer"
            >
              <Eye className="w-3 h-3 hidden sm:inline" />
              <span>Live Preview</span>
            </button>
          </div>
        </div>
      </div>
    </article>
  );
}
