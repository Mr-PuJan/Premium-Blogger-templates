import { useState, useMemo } from 'react';
import {
  ChevronRight,
  SlidersHorizontal,
  LayoutGrid,
  List,
  X,
  Star,
  Search,
  ShoppingCart,
  Eye,
  Heart,
  Check,
  ArrowLeft,
} from 'lucide-react';
import { MainCategory, ThemeItem } from '../data/marketplaceData';
import { ThemeCard } from './ThemeCard';
import { ThemeThumbnail } from './ThemeThumbnail';

interface CatalogViewProps {
  allItems: ThemeItem[];
  searchQuery: string;
  selectedCategory: MainCategory;
  authorFilter: string | null;
  sortBy: 'bestseller' | 'newest' | 'rating' | 'price-asc' | 'price-desc';
  cartIds: number[];
  favoriteIds: number[];
  onSearchQueryChange: (q: string) => void;
  onSelectCategory: (cat: MainCategory) => void;
  onChangeSort: (sort: 'bestseller' | 'newest' | 'rating' | 'price-asc' | 'price-desc') => void;
  onClearAuthor: () => void;
  onResetToHome: () => void;
  onInspect: (item: ThemeItem) => void;
  onLivePreview: (item: ThemeItem) => void;
  onAddToCart: (item: ThemeItem) => void;
  onToggleFavorite: (item: ThemeItem) => void;
  onFilterByAuthor: (author: string) => void;
}

const CATEGORIES: MainCategory[] = [
  'All Items',
  'WordPress',
  'eCommerce',
  'Site Templates',
  'Marketing',
  'CMS',
  'UI Templates',
  'Blogging',
];

const PLATFORM_FILTERS = [
  'Elementor',
  'WooCommerce',
  'Shopify',
  'Tailwind CSS',
  'React',
  'Figma',
  'Webflow',
];

export function CatalogView({
  allItems,
  searchQuery,
  selectedCategory,
  authorFilter,
  sortBy,
  cartIds,
  favoriteIds,
  onSearchQueryChange,
  onSelectCategory,
  onChangeSort,
  onClearAuthor,
  onResetToHome,
  onInspect,
  onLivePreview,
  onAddToCart,
  onToggleFavorite,
  onFilterByAuthor,
}: CatalogViewProps) {
  const [priceBucket, setPriceBucket] = useState<'all' | 'under30' | '30to65' | 'over65'>('all');
  const [minRating, setMinRating] = useState<number>(0);
  const [selectedPlatform, setSelectedPlatform] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [mobileFiltersOpen, setMobileFiltersOpen] = useState(false);

  const filteredItems = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return allItems
      .filter((item) => {
        if (selectedCategory !== 'All Items' && item.category !== selectedCategory) {
          return false;
        }
        if (authorFilter && item.author.toLowerCase() !== authorFilter.toLowerCase()) {
          return false;
        }
        if (q) {
          const haystack = [
            item.title,
            item.author,
            item.category,
            item.subCategory,
            ...item.platformTags,
            ...item.compatibleWith,
          ]
            .join(' ')
            .toLowerCase();
          if (!haystack.includes(q)) return false;
        }
        if (priceBucket === 'under30' && item.price >= 30) return false;
        if (priceBucket === '30to65' && (item.price < 30 || item.price > 65)) return false;
        if (priceBucket === 'over65' && item.price <= 65) return false;
        if (minRating > 0 && item.rating < minRating) return false;
        if (selectedPlatform) {
          const matchesTag =
            item.platformTags.some((t) =>
              t.toLowerCase().includes(selectedPlatform.toLowerCase())
            ) ||
            item.compatibleWith.some((t) =>
              t.toLowerCase().includes(selectedPlatform.toLowerCase())
            ) ||
            item.subCategory.toLowerCase().includes(selectedPlatform.toLowerCase());
          if (!matchesTag) return false;
        }
        return true;
      })
      .sort((a, b) => {
        switch (sortBy) {
          case 'bestseller':
            return b.sales - a.sales;
          case 'rating':
            return b.rating - a.rating || b.reviewsNumeric - a.reviewsNumeric;
          case 'price-asc':
            return a.price - b.price;
          case 'price-desc':
            return b.price - a.price;
          case 'newest':
          default:
            return b.id - a.id;
        }
      });
  }, [
    allItems,
    searchQuery,
    selectedCategory,
    authorFilter,
    priceBucket,
    minRating,
    selectedPlatform,
    sortBy,
  ]);

  const clearAllFilters = () => {
    onSearchQueryChange('');
    onSelectCategory('All Items');
    onClearAuthor();
    setPriceBucket('all');
    setMinRating(0);
    setSelectedPlatform(null);
  };

  return (
    <section className="bg-[#F5F5F5] min-h-[70vh] py-8 border-b border-[#E1E8ED]">
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6">
        {/* Top Breadcrumb & Back to Home */}
        <div className="flex flex-wrap items-center justify-between gap-4 mb-5">
          <div className="flex items-center gap-1.5 text-[13px] text-[#666666]">
            <button
              type="button"
              onClick={onResetToHome}
              className="hover:text-[#262626] hover:underline cursor-pointer"
            >
              Home
            </button>
            <ChevronRight className="w-3.5 h-3.5 text-[#999999]" />
            <span className="text-[#444444]">Files</span>
            <ChevronRight className="w-3.5 h-3.5 text-[#999999]" />
            <span className="font-semibold text-[#262626]">
              {authorFilter ? `Author: ${authorFilter}` : selectedCategory}
            </span>
          </div>

          <button
            type="button"
            onClick={onResetToHome}
            className="inline-flex items-center gap-1.5 text-[13px] font-semibold text-[#0084B4] hover:underline cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to ThemeForest Homepage</span>
          </button>
        </div>

        {/* Title & Inline Search Bar */}
        <div className="bg-white border border-[#E1E8ED] rounded-md p-5 mb-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-[22px] sm:text-[26px] font-bold text-[#262626]">
              {authorFilter
                ? `Portfolio by ${authorFilter}`
                : selectedCategory === 'All Items'
                ? 'WordPress Themes & Website Templates'
                : `${selectedCategory} Themes & Templates`}
            </h1>
            <p className="text-[13.5px] text-[#666666] mt-0.5">
              Showing <span className="font-bold text-[#262626]">{filteredItems.length}</span>{' '}
              quality-reviewed results
              {searchQuery && (
                <>
                  {' '}
                  for <span className="font-semibold text-[#262626]">&ldquo;{searchQuery}&rdquo;</span>
                </>
              )}
            </p>
          </div>

          <div className="flex items-center gap-2 w-full md:w-[340px]">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-[#888888] absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => onSearchQueryChange(e.target.value)}
                placeholder="Refine search..."
                className="w-full pl-9 pr-8 py-2 text-[13.5px] border border-[#DCE1E5] rounded bg-[#FAFAFA] focus:bg-white focus:outline-none focus:border-[#82B541]"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => onSearchQueryChange('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#888888] hover:text-[#262626] cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
            <button
              type="button"
              onClick={() => setMobileFiltersOpen(!mobileFiltersOpen)}
              className="lg:hidden px-3 py-2 rounded border border-[#DCE1E5] bg-white text-[13px] font-medium flex items-center gap-1.5"
            >
              <SlidersHorizontal className="w-4 h-4" />
              <span>Filters</span>
            </button>
          </div>
        </div>

        {/* Main 2-Column Catalog Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Left Filter Sidebar */}
          <aside
            className={`lg:col-span-3 bg-white border border-[#E1E8ED] rounded-md p-5 space-y-6 ${
              mobileFiltersOpen ? 'block' : 'hidden lg:block'
            }`}
          >
            <div className="flex items-center justify-between border-b border-[#EEEEEE] pb-3">
              <span className="font-bold text-[14px] text-[#262626] flex items-center gap-2">
                <SlidersHorizontal className="w-4 h-4 text-[#82B541]" />
                Filter &amp; Refine
              </span>
              <button
                type="button"
                onClick={clearAllFilters}
                className="text-[12px] text-[#0084B4] hover:underline cursor-pointer"
              >
                Clear all
              </button>
            </div>

            {/* Category List */}
            <div className="space-y-2">
              <h4 className="text-[12px] font-bold uppercase tracking-wider text-[#888888]">
                Category
              </h4>
              <div className="space-y-1">
                {CATEGORIES.map((cat) => {
                  const count =
                    cat === 'All Items'
                      ? allItems.length
                      : allItems.filter((i) => i.category === cat).length;
                  const active = selectedCategory === cat;
                  return (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => onSelectCategory(cat)}
                      className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded text-[13px] transition-colors cursor-pointer ${
                        active
                          ? 'bg-[#82B541]/15 text-[#4E741E] font-semibold'
                          : 'text-[#555555] hover:bg-[#F5F5F5]'
                      }`}
                    >
                      <span>{cat}</span>
                      <span className="text-[11.5px] text-[#888888]">{count}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Price Range */}
            <div className="space-y-2 pt-2 border-t border-[#F0F2F4]">
              <h4 className="text-[12px] font-bold uppercase tracking-wider text-[#888888]">
                Price
              </h4>
              <div className="space-y-1 text-[13px]">
                {[
                  { id: 'all', label: 'Any Price' },
                  { id: 'under30', label: 'Under $30' },
                  { id: '30to65', label: '$30 – $65' },
                  { id: 'over65', label: '$65+' },
                ].map((opt) => (
                  <label
                    key={opt.id}
                    className="flex items-center gap-2 py-1 cursor-pointer text-[#555555] hover:text-[#262626]"
                  >
                    <input
                      type="radio"
                      name="priceBucket"
                      checked={priceBucket === opt.id}
                      onChange={() =>
                        setPriceBucket(opt.id as 'all' | 'under30' | '30to65' | 'over65')
                      }
                      className="accent-[#82B541]"
                    />
                    <span>{opt.label}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Rating */}
            <div className="space-y-2 pt-2 border-t border-[#F0F2F4]">
              <h4 className="text-[12px] font-bold uppercase tracking-wider text-[#888888]">
                Rating
              </h4>
              <div className="space-y-1 text-[13px]">
                {[
                  { val: 0, label: 'Show all' },
                  { val: 4.8, label: '4.8 stars & higher' },
                  { val: 4.9, label: '4.9 stars & higher' },
                ].map((r) => (
                  <label
                    key={r.val}
                    className="flex items-center gap-2 py-1 cursor-pointer text-[#555555] hover:text-[#262626]"
                  >
                    <input
                      type="radio"
                      name="minRating"
                      checked={minRating === r.val}
                      onChange={() => setMinRating(r.val)}
                      className="accent-[#82B541]"
                    />
                    <span>{r.label}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Platform Tags */}
            <div className="space-y-2 pt-2 border-t border-[#F0F2F4]">
              <h4 className="text-[12px] font-bold uppercase tracking-wider text-[#888888]">
                Compatible With
              </h4>
              <div className="flex flex-wrap gap-1.5">
                {PLATFORM_FILTERS.map((tag) => {
                  const active = selectedPlatform === tag;
                  return (
                    <button
                      key={tag}
                      type="button"
                      onClick={() => setSelectedPlatform(active ? null : tag)}
                      className={`px-2.5 py-1 rounded text-[12px] font-medium border transition-colors cursor-pointer ${
                        active
                          ? 'bg-[#262626] text-white border-[#262626]'
                          : 'bg-[#F9FAFB] text-[#555555] border-[#DCE1E5] hover:border-[#999999]'
                      }`}
                    >
                      {tag}
                    </button>
                  );
                })}
              </div>
            </div>
          </aside>

          {/* Right Results Area */}
          <div className="lg:col-span-9 space-y-5">
            {/* Toolbar: Active Chips + Sort + Grid/List Switch */}
            <div className="bg-white border border-[#E1E8ED] rounded-md px-4 py-3 flex flex-wrap items-center justify-between gap-3">
              <div className="flex flex-wrap items-center gap-2">
                {authorFilter && (
                  <span className="inline-flex items-center gap-1 bg-[#262626] text-white text-[12px] px-2.5 py-1 rounded-full">
                    Author: {authorFilter}
                    <button onClick={onClearAuthor} className="hover:text-rose-300 cursor-pointer">
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                )}
                {selectedPlatform && (
                  <span className="inline-flex items-center gap-1 bg-[#82B541]/15 text-[#4E741E] text-[12px] font-semibold px-2.5 py-1 rounded-full">
                    {selectedPlatform}
                    <button
                      onClick={() => setSelectedPlatform(null)}
                      className="hover:text-[#262626] cursor-pointer"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                )}
                {!authorFilter && !selectedPlatform && (
                  <span className="text-[13px] text-[#666666]">
                    Sort and inspect items in real time
                  </span>
                )}
              </div>

              <div className="flex items-center gap-3 ml-auto">
                <div className="flex items-center gap-2 text-[13px]">
                  <span className="text-[#777777] hidden sm:inline">Sort by:</span>
                  <select
                    value={sortBy}
                    onChange={(e) =>
                      onChangeSort(
                        e.target.value as
                          | 'bestseller'
                          | 'newest'
                          | 'rating'
                          | 'price-asc'
                          | 'price-desc'
                      )
                    }
                    className="border border-[#DCE1E5] rounded px-2.5 py-1.5 text-[13px] text-[#333333] bg-[#FAFAFA] focus:outline-none cursor-pointer"
                  >
                    <option value="bestseller">Best sellers</option>
                    <option value="newest">Newest items</option>
                    <option value="rating">Best rated</option>
                    <option value="price-asc">Price: low to high</option>
                    <option value="price-desc">Price: high to low</option>
                  </select>
                </div>

                <div className="flex items-center border border-[#DCE1E5] rounded overflow-hidden">
                  <button
                    type="button"
                    onClick={() => setViewMode('grid')}
                    aria-label="Grid view"
                    className={`p-1.5 cursor-pointer ${
                      viewMode === 'grid'
                        ? 'bg-[#262626] text-white'
                        : 'bg-white text-[#666666] hover:bg-[#F5F5F5]'
                    }`}
                  >
                    <LayoutGrid className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setViewMode('list')}
                    aria-label="List view"
                    className={`p-1.5 cursor-pointer ${
                      viewMode === 'list'
                        ? 'bg-[#262626] text-white'
                        : 'bg-white text-[#666666] hover:bg-[#F5F5F5]'
                    }`}
                  >
                    <List className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>

            {/* Empty State */}
            {filteredItems.length === 0 ? (
              <div className="bg-white border border-[#E1E8ED] rounded-md p-12 text-center space-y-3">
                <p className="text-[17px] font-bold text-[#262626]">
                  No items matched your selected filters
                </p>
                <p className="text-[14px] text-[#666666]">
                  Try clearing a filter or searching for &ldquo;WordPress&rdquo;, &ldquo;Shopify&rdquo;, or &ldquo;Admin&rdquo;.
                </p>
                <button
                  type="button"
                  onClick={clearAllFilters}
                  className="tf-btn-green px-5 py-2 rounded text-[13px] font-semibold cursor-pointer"
                >
                  Reset Filters
                </button>
              </div>
            ) : viewMode === 'grid' ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
                {filteredItems.map((item) => (
                  <ThemeCard
                    key={item.id}
                    item={item}
                    isInCart={cartIds.includes(item.id)}
                    isFavorite={favoriteIds.includes(item.id)}
                    onInspect={onInspect}
                    onLivePreview={onLivePreview}
                    onAddToCart={onAddToCart}
                    onToggleFavorite={onToggleFavorite}
                    onFilterByAuthor={onFilterByAuthor}
                  />
                ))}
              </div>
            ) : (
              /* Detailed ThemeForest List View */
              <div className="space-y-4">
                {filteredItems.map((item) => {
                  const inCart = cartIds.includes(item.id);
                  const fav = favoriteIds.includes(item.id);
                  return (
                    <div
                      key={item.id}
                      className="tf-card p-4 flex flex-col sm:flex-row gap-5 items-stretch"
                    >
                      <div
                        onClick={() => onInspect(item)}
                        className="sm:w-[270px] aspect-[590/300] rounded overflow-hidden shrink-0 border border-[#EAECEF] cursor-pointer"
                      >
                        <ThemeThumbnail item={item} />
                      </div>
                      <div className="flex-1 flex flex-col justify-between min-w-0">
                        <div>
                          <div className="flex items-start justify-between gap-3">
                            <h3
                              onClick={() => onInspect(item)}
                              className="text-[16px] font-bold text-[#262626] hover:text-[#0084B4] cursor-pointer leading-snug"
                            >
                              {item.title}
                            </h3>
                            <button
                              type="button"
                              onClick={() => onToggleFavorite(item)}
                              className={`p-1.5 rounded-full cursor-pointer ${
                                fav ? 'text-rose-500' : 'text-[#999999] hover:text-rose-500'
                              }`}
                            >
                              <Heart className={`w-4 h-4 ${fav ? 'fill-current' : ''}`} />
                            </button>
                          </div>
                          <p className="text-[12.5px] text-[#777777] mt-1">
                            by{' '}
                            <button
                              type="button"
                              onClick={() => onFilterByAuthor(item.author)}
                              className="font-semibold text-[#555555] hover:underline cursor-pointer"
                            >
                              {item.author}
                            </button>{' '}
                            in {item.category} / {item.subCategory}
                          </p>
                          <ul className="mt-2.5 space-y-1 text-[12.5px] text-[#555555] hidden md:block">
                            {item.highlights.slice(0, 2).map((h, i) => (
                              <li key={i} className="truncate">
                                • {h}
                              </li>
                            ))}
                          </ul>
                        </div>
                        <div className="flex flex-wrap items-center gap-1.5 mt-3">
                          {item.platformTags.map((t) => (
                            <span
                              key={t}
                              className="text-[11px] bg-[#F3F4F6] text-[#555555] px-2 py-0.5 rounded"
                            >
                              {t}
                            </span>
                          ))}
                        </div>
                      </div>
                      <div className="sm:w-[170px] sm:border-l sm:border-[#EEEEEE] sm:pl-4 flex sm:flex-col justify-between items-end sm:items-center text-right sm:text-center shrink-0">
                        <div>
                          <div className="text-[22px] font-extrabold text-[#262626]">
                            ${item.price}
                          </div>
                          <div className="flex items-center justify-end sm:justify-center gap-0.5 text-[#F5A623] mt-1">
                            {Array.from({ length: 5 }).map((_, i) => (
                              <Star key={i} className="w-3 h-3 fill-current" />
                            ))}
                            <span className="text-[11px] text-[#777777] ml-1">
                              ({item.reviewsCount})
                            </span>
                          </div>
                          <div className="text-[11.5px] text-[#888888] mt-0.5">
                            {item.salesFormatted} · Updated {item.lastUpdated}
                          </div>
                        </div>

                        <div className="flex sm:flex-col gap-2 w-auto sm:w-full mt-2">
                          <button
                            type="button"
                            onClick={() => onAddToCart(item)}
                            className={`px-3 py-2 rounded text-[12.5px] font-semibold flex items-center justify-center gap-1.5 cursor-pointer ${
                              inCart
                                ? 'bg-[#82B541] text-white'
                                : 'tf-btn-green'
                            }`}
                          >
                            {inCart ? (
                              <>
                                <Check className="w-3.5 h-3.5" />
                                <span>In Cart</span>
                              </>
                            ) : (
                              <>
                                <ShoppingCart className="w-3.5 h-3.5" />
                                <span>Add to Cart</span>
                              </>
                            )}
                          </button>
                          <button
                            type="button"
                            onClick={() => onLivePreview(item)}
                            className="px-3 py-1.5 rounded border border-[#CCCCCC] hover:border-[#0084B4] hover:text-[#0084B4] text-[12px] font-medium flex items-center justify-center gap-1 cursor-pointer"
                          >
                            <Eye className="w-3.5 h-3.5" />
                            <span>Live Preview</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
