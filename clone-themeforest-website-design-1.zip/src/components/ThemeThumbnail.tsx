import { ThemeItem } from '../data/marketplaceData';

interface Props {
  item: ThemeItem;
  className?: string;
}

export function ThemeThumbnail({ item, className = '' }: Props) {
  if (item.imageUrl) {
    return (
      <img
        src={item.imageUrl}
        alt={item.title}
        loading="lazy"
        className={`w-full h-full object-cover object-top ${className}`}
      />
    );
  }

  // Bespoke 2:1 ThemeForest cover art tailored to each theme's real visual identity
  return (
    <div className={`w-full h-full relative overflow-hidden select-none ${className}`}>
      {renderCustomArt(item)}
    </div>
  );
}

function renderCustomArt(item: ThemeItem) {
  switch (item.artVariant) {
    case 'avone':
      return (
        <div className="w-full h-full bg-gradient-to-br from-[#F4EFEA] via-[#ECE4DB] to-[#E2D5C8] p-3 flex items-center justify-between gap-2.5">
          {/* Desktop browser */}
          <div className="w-[74%] h-full bg-white rounded-md shadow-md border border-black/10 overflow-hidden flex flex-col">
            <div className="h-3.5 bg-[#FAF8F6] border-b border-neutral-200 px-2 flex items-center justify-between">
              <div className="flex gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-rose-400" />
                <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
              </div>
              <span className="text-[7px] font-semibold tracking-widest text-neutral-500">AVONE · OS 3.0</span>
              <span className="text-[6px] bg-black text-white px-1 rounded">SHOP</span>
            </div>
            <div className="flex-1 grid grid-cols-12 gap-1.5 p-2">
              <div className="col-span-6 bg-[#F6F1EC] rounded p-2 flex flex-col justify-between">
                <span className="text-[6px] uppercase tracking-widest text-[#9C7A5B] font-bold">Spring Lookbook</span>
                <div>
                  <div className="text-[11px] font-bold leading-tight text-neutral-900">Minimalist Tailoring</div>
                  <div className="text-[6.5px] text-neutral-500 mt-0.5">38+ Shopify Store Demos</div>
                </div>
                <span className="inline-block w-fit bg-neutral-900 text-white text-[6.5px] px-2 py-0.5 rounded-sm font-medium">
                  Explore Edit
                </span>
              </div>
              <div className="col-span-6 grid grid-cols-2 gap-1.5">
                {[
                  { bg: 'bg-[#E5D8CA]', price: '$245', label: 'Linen Coat' },
                  { bg: 'bg-[#D7E0E2]', price: '$160', label: 'Silk Shirt' },
                  { bg: 'bg-[#E8D5D5]', price: '$310', label: 'Leather Tote' },
                  { bg: 'bg-[#DDE3D5]', price: '$185', label: 'Wool Knit' },
                ].map((p, idx) => (
                  <div key={idx} className="bg-neutral-50 border border-neutral-100 rounded p-1 flex flex-col justify-between">
                    <div className={`h-7 ${p.bg} rounded-sm`} />
                    <div className="flex items-center justify-between text-[6px] font-semibold text-neutral-700 mt-0.5">
                      <span className="truncate">{p.label}</span>
                      <span>{p.price}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
          {/* Phone screen */}
          <div className="w-[24%] h-[92%] bg-neutral-900 rounded-xl p-1 shadow-lg flex flex-col">
            <div className="bg-white flex-1 rounded-lg p-1.5 flex flex-col gap-1 overflow-hidden">
              <div className="text-[7px] font-bold text-center tracking-wider">AVONE</div>
              <div className="h-12 bg-[#EBDFD3] rounded-sm flex items-end p-1">
                <span className="text-[6px] font-bold text-neutral-800">NEW IN</span>
              </div>
              <div className="grid grid-cols-2 gap-1 flex-1">
                <div className="bg-neutral-100 rounded-sm" />
                <div className="bg-neutral-100 rounded-sm" />
              </div>
            </div>
          </div>
        </div>
      );

    case 'paces':
      return (
        <div className="w-full h-full bg-gradient-to-br from-[#EEF2FF] via-[#E0E7FF] to-[#DBEAFE] p-3 flex items-center justify-center">
          <div className="w-full h-full bg-white rounded-md shadow-md border border-indigo-200/70 overflow-hidden flex">
            {/* Dark sidebar */}
            <div className="w-[22%] bg-[#1E1B4B] text-white p-2 flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-1 mb-2">
                  <div className="w-3 h-3 rounded bg-indigo-500" />
                  <span className="text-[8px] font-bold tracking-wide">Paces</span>
                </div>
                <div className="space-y-1">
                  {['Analytics', 'CRM Sales', 'AI Chat', 'Kanban', 'Billing'].map((nav, i) => (
                    <div
                      key={nav}
                      className={`text-[6.5px] px-1.5 py-0.5 rounded ${
                        i === 0 ? 'bg-indigo-500/80 text-white font-semibold' : 'text-indigo-200/80'
                      }`}
                    >
                      {nav}
                    </div>
                  ))}
                </div>
              </div>
              <div className="text-[6px] bg-indigo-900/70 px-1.5 py-1 rounded text-indigo-200">
                Tailwind v4 · React
              </div>
            </div>
            {/* Dashboard content */}
            <div className="flex-1 bg-[#F8FAFC] p-2.5 flex flex-col gap-2">
              <div className="flex items-center justify-between">
                <span className="text-[8px] font-bold text-slate-800">Revenue Analytics</span>
                <span className="text-[6px] bg-emerald-100 text-emerald-700 px-1.5 py-0.5 rounded-full font-semibold">
                  +24.8% YoY
                </span>
              </div>
              <div className="grid grid-cols-3 gap-1.5">
                {[
                  { label: 'MRR', val: '$84.2K', col: 'text-indigo-600' },
                  { label: 'Active Users', val: '18,492', col: 'text-emerald-600' },
                  { label: 'Retention', val: '98.4%', col: 'text-amber-600' },
                ].map((k) => (
                  <div key={k.label} className="bg-white rounded p-1.5 border border-slate-200/70">
                    <div className="text-[6px] text-slate-400">{k.label}</div>
                    <div className={`text-[9px] font-bold ${k.col}`}>{k.val}</div>
                  </div>
                ))}
              </div>
              <div className="flex-1 bg-white rounded border border-slate-200/70 p-1.5 flex items-end gap-1">
                {[38, 55, 44, 72, 62, 85, 76, 94, 88, 100].map((h, i) => (
                  <div
                    key={i}
                    className="flex-1 rounded-t bg-gradient-to-t from-indigo-600 to-cyan-400"
                    style={{ height: `${h}%` }}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      );

    case 'atomik':
    case 'trigger':
    case 'zeyna':
    case 'salient':
      const darkAccent =
        item.artVariant === 'atomik'
          ? 'from-[#FF5C35] to-[#F97316]'
          : item.artVariant === 'trigger'
          ? 'from-[#A855F7] to-[#EC4899]'
          : item.artVariant === 'salient'
          ? 'from-[#FF4C60] to-[#F43F5E]'
          : 'from-[#7C3AED] to-[#3B82F6]';
      return (
        <div className="w-full h-full bg-[#0F1117] p-3 flex flex-col justify-between relative overflow-hidden">
          <div
            className={`absolute -top-10 -right-10 w-40 h-40 rounded-full bg-gradient-to-br ${darkAccent} opacity-25 blur-xl`}
          />
          <div className="flex items-center justify-between text-white/80 z-10">
            <span className="text-[8px] font-bold tracking-widest uppercase">
              {item.demoConfig.brandName}
            </span>
            <div className="flex gap-1.5 text-[6px] text-white/60">
              <span>Work</span>
              <span>Studio</span>
              <span className="px-1.5 py-0.5 rounded bg-white/15 text-white">Elementor</span>
            </div>
          </div>
          <div className="z-10 my-auto">
            <div className="inline-flex items-center gap-1 text-[6px] uppercase tracking-widest px-1.5 py-0.5 rounded-full bg-white/10 text-white/80 mb-1">
              <span className={`w-1.5 h-1.5 rounded-full bg-gradient-to-r ${darkAccent}`} />
              Creative Agency WordPress
            </div>
            <h4 className="text-[13px] font-extrabold text-white leading-tight max-w-[85%]">
              {item.demoConfig.headline}
            </h4>
          </div>
          <div className="grid grid-cols-3 gap-1.5 z-10">
            {item.demoConfig.sampleCards.map((c, idx) => (
              <div
                key={idx}
                className="bg-white/10 backdrop-blur border border-white/15 rounded p-1.5 text-white"
              >
                <div className={`h-5 rounded-sm bg-gradient-to-r ${darkAccent} opacity-80 mb-1`} />
                <div className="text-[6.5px] font-semibold truncate">{c.title}</div>
                <div className="text-[5.5px] text-white/60 truncate">{c.tag}</div>
              </div>
            ))}
          </div>
        </div>
      );

    case 'nexsas':
    case 'aiann':
    case 'hostify':
      return (
        <div className="w-full h-full bg-gradient-to-br from-[#090D16] via-[#0F172A] to-[#1E1B4B] p-3 flex flex-col justify-between text-white relative">
          <div className="flex items-center justify-between">
            <span className="text-[8px] font-bold text-cyan-300 tracking-wide">
              {item.demoConfig.brandName}
            </span>
            <span className="text-[6px] bg-indigo-500/30 border border-indigo-400/40 text-indigo-200 px-1.5 py-0.5 rounded-full">
              AI &amp; SaaS Ready
            </span>
          </div>
          <div className="grid grid-cols-12 gap-2 items-center my-auto">
            <div className="col-span-7 space-y-1">
              <div className="text-[11px] font-extrabold leading-tight">
                {item.demoConfig.headline}
              </div>
              <div className="text-[6.5px] text-slate-300 line-clamp-2">
                {item.demoConfig.subheadline}
              </div>
              <div className="flex gap-1 pt-0.5">
                <span className="bg-indigo-500 text-white text-[6.5px] font-semibold px-2 py-0.5 rounded">
                  Get Started
                </span>
                <span className="bg-white/10 text-white text-[6.5px] px-2 py-0.5 rounded">
                  Live API
                </span>
              </div>
            </div>
            <div className="col-span-5 bg-slate-900/90 border border-cyan-500/30 rounded-md p-1.5 space-y-1">
              <div className="flex justify-between text-[6px] text-cyan-300 font-semibold">
                <span>Model Telemetry</span>
                <span>99.9%</span>
              </div>
              <div className="h-10 flex items-end gap-0.5">
                {[35, 60, 48, 82, 70, 95, 89].map((v, i) => (
                  <div
                    key={i}
                    className="flex-1 bg-gradient-to-t from-indigo-500 to-cyan-400 rounded-t-sm"
                    style={{ height: `${v}%` }}
                  />
                ))}
              </div>
            </div>
          </div>
          <div className="flex gap-1.5">
            {item.demoConfig.stats.map((s) => (
              <div key={s.label} className="flex-1 bg-white/5 border border-white/10 rounded px-1.5 py-0.5">
                <div className="text-[7.5px] font-bold text-cyan-300">{s.value}</div>
                <div className="text-[5.5px] text-slate-400">{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      );

    case 'flatsome':
      return (
        <div className="w-full h-full bg-gradient-to-br from-[#F1F5F9] to-[#E2E8F0] p-3 flex items-center gap-2">
          <div className="flex-1 h-full bg-white rounded-md shadow border border-slate-200 overflow-hidden flex flex-col">
            <div className="h-4 bg-[#2B3A4A] text-white px-2 flex items-center justify-between">
              <span className="text-[7px] font-bold tracking-wider">FLATSOME</span>
              <span className="text-[6px] bg-[#82B541] px-1.5 rounded font-semibold">252K+ SALES</span>
            </div>
            <div className="p-2 flex-1 flex flex-col gap-1.5">
              <div className="bg-gradient-to-r from-[#334155] to-[#475569] text-white rounded p-2 flex items-center justify-between">
                <div>
                  <div className="text-[9px] font-bold">UX Builder Storefront</div>
                  <div className="text-[6px] text-slate-200">WooCommerce #1 Retail Theme</div>
                </div>
                <span className="bg-white text-slate-900 text-[6px] font-bold px-1.5 py-0.5 rounded">
                  SHOP NOW
                </span>
              </div>
              <div className="grid grid-cols-3 gap-1.5 flex-1">
                {['Apparel', 'Watches', 'Footwear'].map((cat, idx) => (
                  <div key={cat} className="bg-slate-50 border border-slate-100 rounded p-1 flex flex-col justify-between">
                    <div
                      className={`h-8 rounded-sm ${
                        idx === 0 ? 'bg-amber-100' : idx === 1 ? 'bg-sky-100' : 'bg-emerald-100'
                      }`}
                    />
                    <div className="text-[6.5px] font-semibold text-slate-700 text-center">{cat}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      );

    case 'kicker':
      return (
        <div className="w-full h-full bg-[#FAF9F7] p-3 flex flex-col justify-between border-b border-neutral-200">
          <div className="border-b-2 border-neutral-900 pb-1 flex items-center justify-between">
            <span className="text-[10px] font-black tracking-tight text-neutral-900">THE KICKER.</span>
            <span className="text-[6px] bg-rose-600 text-white px-1.5 py-0.5 rounded font-bold">
              18 MAGAZINE SKINS
            </span>
          </div>
          <div className="grid grid-cols-12 gap-2 flex-1 pt-2">
            <div className="col-span-7 bg-neutral-900 text-white rounded p-2 flex flex-col justify-between">
              <span className="text-[6px] uppercase tracking-widest text-rose-400 font-bold">Cover Story</span>
              <div>
                <div className="text-[9.5px] font-bold leading-snug">
                  Spatial Computing &amp; Editorial Design in 2026
                </div>
                <div className="text-[6px] text-neutral-400 mt-0.5">AMP Ready · 99 PageSpeed</div>
              </div>
            </div>
            <div className="col-span-5 flex flex-col gap-1.5">
              {item.demoConfig.sampleCards.slice(0, 2).map((c, idx) => (
                <div key={idx} className="flex-1 bg-white border border-neutral-200 rounded p-1.5 flex flex-col justify-center">
                  <div className="text-[5.5px] font-bold text-rose-600 uppercase">{c.tag}</div>
                  <div className="text-[7px] font-bold text-neutral-900 line-clamp-1">{c.title}</div>
                  <div className="text-[5.5px] text-neutral-500">{c.subtitle}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      );

    case 'goal':
    case 'fcunited':
      return (
        <div className="w-full h-full bg-gradient-to-br from-[#0F172A] via-[#1E293B] to-[#064E3B] p-3 flex flex-col justify-between text-white">
          <div className="flex items-center justify-between">
            <span className="text-[8.5px] font-extrabold tracking-wider">{item.demoConfig.brandName}</span>
            <span className="text-[6px] bg-emerald-500 text-slate-950 font-bold px-1.5 py-0.5 rounded">
              SPORTSPRESS
            </span>
          </div>
          <div className="bg-white/10 border border-white/15 rounded-md p-2 flex items-center justify-between">
            <div>
              <div className="text-[6px] text-emerald-300 uppercase font-bold">Live Match Center</div>
              <div className="text-[10px] font-extrabold mt-0.5">METRO 3 : 1 APEX</div>
              <div className="text-[6px] text-slate-300">League Fixtures · Squads · Club Shop</div>
            </div>
            <div className="w-10 h-10 rounded-full bg-emerald-500/20 border border-emerald-400/50 flex items-center justify-center text-[8px] font-black text-emerald-300">
              LIVE
            </div>
          </div>
          <div className="grid grid-cols-3 gap-1.5">
            {item.demoConfig.stats.map((s) => (
              <div key={s.label} className="bg-black/30 rounded px-1.5 py-1 text-center">
                <div className="text-[8px] font-bold text-amber-400">{s.value}</div>
                <div className="text-[5.5px] text-slate-300">{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      );

    default:
      // Clean crisp corporate / Swiss / marketing / education / Webflow showcase
      return (
        <div className="w-full h-full bg-gradient-to-br from-[#F8FAFC] to-[#E2E8F0] p-3 flex items-center justify-center">
          <div className="w-full h-full bg-white rounded-md shadow border border-slate-200 overflow-hidden flex flex-col">
            <div
              className="h-4 px-2 flex items-center justify-between text-white"
              style={{ backgroundColor: item.demoConfig.primaryColor }}
            >
              <span className="text-[7px] font-bold tracking-wider">{item.demoConfig.brandName}</span>
              <span
                className="text-[5.5px] px-1.5 py-0.2 rounded font-semibold"
                style={{ backgroundColor: item.demoConfig.accentColor, color: '#FFFFFF' }}
              >
                {item.subCategory}
              </span>
            </div>
            <div className="p-2.5 flex-1 flex flex-col justify-between">
              <div>
                <div className="text-[6px] uppercase tracking-wider font-bold text-slate-400">
                  {item.demoConfig.tagline}
                </div>
                <div className="text-[10px] font-extrabold text-slate-900 leading-tight mt-0.5">
                  {item.demoConfig.headline}
                </div>
              </div>
              <div className="grid grid-cols-3 gap-1.5 mt-1.5">
                {item.demoConfig.sampleCards.map((c, idx) => (
                  <div key={idx} className="bg-slate-50 border border-slate-200/80 rounded p-1.5">
                    <div className="text-[6px] font-bold text-slate-800 truncate">{c.title}</div>
                    <div className="text-[5.5px] text-slate-500 truncate mt-0.5">{c.subtitle}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      );
  }
}
