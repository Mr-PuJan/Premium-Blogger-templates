import React from 'react';
import { Search, Sparkles } from 'lucide-react';
import { MainCategory, ThemeItem } from '../data/marketplaceData';

interface HeroSectionProps {
  searchQuery: string;
  searchCategory: MainCategory;
  onSearchQueryChange: (val: string) => void;
  onSearchCategoryChange: (cat: MainCategory) => void;
  onSubmitSearch: (customQuery?: string) => void;
  featuredShowcaseItems: ThemeItem[];
  onInspectItem: (item: ThemeItem) => void;
}

const QUICK_TAGS = [
  'Elementor',
  'WooCommerce',
  'Shopify',
  'SaaS',
  'Admin',
  'Portfolio',
];

export function HeroSection({
  searchQuery,
  searchCategory,
  onSearchQueryChange,
  onSearchCategoryChange,
  onSubmitSearch,
  featuredShowcaseItems,
  onInspectItem,
}: HeroSectionProps) {
  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmitSearch();
  };

  const avada = featuredShowcaseItems.find((i) => i.id === 2833226) || featuredShowcaseItems[0];
  const woodmart = featuredShowcaseItems.find((i) => i.id === 20264492) || featuredShowcaseItems[1];
  const wolmart = featuredShowcaseItems.find((i) => i.id === 32947681) || featuredShowcaseItems[2];
  const listeo = featuredShowcaseItems.find((i) => i.id === 23239259) || featuredShowcaseItems[3];

  return (
    <section className="bg-[#F5F5F5] pt-10 pb-12 sm:pt-12 sm:pb-14 overflow-hidden">
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-center">
          {/* Left Column: Headline, Subcopy, Search Bar */}
          <div className="lg:col-span-6 space-y-5">
            <h1 className="text-[30px] sm:text-[36px] lg:text-[40px] font-extrabold text-[#262626] leading-[1.18] tracking-[-0.02em]">
              Professional WordPress Themes &amp; Website Templates for any project
            </h1>
            <p className="text-[16px] sm:text-[17px] text-[#555555] leading-relaxed max-w-[540px]">
              Discover thousands of easy to customize themes, templates &amp; CMS
              products, made by world-class developers.
            </p>

            {/* ThemeForest Authentic Search Box */}
            <form
              onSubmit={handleFormSubmit}
              className="bg-white rounded-md shadow-[0_4px_18px_rgba(0,0,0,0.08)] border border-[#DCE1E5] p-1.5 flex flex-col sm:flex-row items-stretch sm:items-center gap-1.5 max-w-[600px]"
            >
              <div className="flex items-center flex-1 min-w-0">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => onSearchQueryChange(e.target.value)}
                  placeholder="e.g. responsive WordPress"
                  className="w-full px-3.5 py-2.5 text-[15px] text-[#262626] placeholder-[#8E959C] bg-transparent focus:outline-none"
                />
              </div>

              <div className="flex items-center gap-1.5 shrink-0">
                <select
                  value={searchCategory}
                  onChange={(e) => onSearchCategoryChange(e.target.value as MainCategory)}
                  aria-label="Filter category"
                  className="h-[42px] px-2.5 text-[13px] text-[#555555] bg-[#F7F8F9] border border-[#E5E8EB] rounded focus:outline-none cursor-pointer"
                >
                  <option value="All Items">All Categories</option>
                  <option value="WordPress">WordPress</option>
                  <option value="eCommerce">eCommerce</option>
                  <option value="Site Templates">Site Templates</option>
                  <option value="Marketing">Marketing</option>
                  <option value="CMS">CMS</option>
                  <option value="UI Templates">UI Templates</option>
                  <option value="Blogging">Blogging</option>
                </select>

                <button
                  type="submit"
                  className="tf-btn-green h-[42px] px-5 rounded font-semibold text-[14px] inline-flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Search className="w-4 h-4 stroke-[2.5]" />
                  <span>Search</span>
                </button>
              </div>
            </form>

            {/* Quick Popular Searches */}
            <div className="flex flex-wrap items-center gap-2 pt-1 text-[12px] text-[#666666]">
              <span className="font-medium text-[#777777]">Popular:</span>
              {QUICK_TAGS.map((tag) => (
                <button
                  key={tag}
                  type="button"
                  onClick={() => onSubmitSearch(tag)}
                  className="px-2.5 py-1 rounded bg-white hover:bg-[#EAECEF] border border-[#E1E5E8] text-[#444444] font-medium transition-colors cursor-pointer"
                >
                  {tag}
                </button>
              ))}
            </div>
          </div>

          {/* Right Column: ThemeForest Layered Multi-Browser Hero Collage */}
          <div className="lg:col-span-6 relative">
            <div className="relative h-[300px] sm:h-[360px] lg:h-[385px] w-full flex items-center justify-center">
              {/* Soft Ambient Radial Glow */}
              <div className="absolute inset-4 bg-gradient-to-tr from-[#82B541]/10 via-sky-500/5 to-transparent rounded-3xl blur-2xl" />

              {/* Back-left card: Listeo */}
              {listeo && (
                <button
                  type="button"
                  onClick={() => onInspectItem(listeo)}
                  className="hidden sm:block absolute left-0 top-5 w-[56%] aspect-[16/9] rounded-lg overflow-hidden shadow-lg border border-black/10 -rotate-2 hover:rotate-0 hover:scale-[1.03] hover:z-30 transition-all duration-300 cursor-pointer bg-white"
                  title={listeo.title}
                >
                  <img
                    src={listeo.imageUrl}
                    alt={listeo.title}
                    className="w-full h-full object-cover object-top"
                  />
                </button>
              )}

              {/* Back-right card: Wolmart */}
              {wolmart && (
                <button
                  type="button"
                  onClick={() => onInspectItem(wolmart)}
                  className="hidden sm:block absolute right-0 top-2 w-[54%] aspect-[16/9] rounded-lg overflow-hidden shadow-lg border border-black/10 rotate-2 hover:rotate-0 hover:scale-[1.03] hover:z-30 transition-all duration-300 cursor-pointer bg-white"
                  title={wolmart.title}
                >
                  <img
                    src={wolmart.imageUrl}
                    alt={wolmart.title}
                    className="w-full h-full object-cover object-top"
                  />
                </button>
              )}

              {/* Bottom-left card: WoodMart */}
              {woodmart && (
                <button
                  type="button"
                  onClick={() => onInspectItem(woodmart)}
                  className="absolute left-2 sm:left-6 bottom-2 w-[58%] sm:w-[54%] aspect-[16/9] rounded-lg overflow-hidden shadow-xl border border-black/10 rotate-1 hover:rotate-0 hover:scale-[1.03] hover:z-30 transition-all duration-300 cursor-pointer bg-white z-10"
                  title={woodmart.title}
                >
                  <img
                    src={woodmart.imageUrl}
                    alt={woodmart.title}
                    className="w-full h-full object-cover object-top"
                  />
                </button>
              )}

              {/* Center Hero Foreground Card: Avada #1 Bestseller */}
              {avada && (
                <button
                  type="button"
                  onClick={() => onInspectItem(avada)}
                  className="relative sm:absolute sm:right-4 sm:bottom-6 w-[88%] sm:w-[66%] aspect-[16/9] rounded-lg overflow-hidden shadow-[0_20px_45px_rgba(0,0,0,0.18)] border border-white ring-1 ring-black/10 hover:scale-[1.02] transition-all duration-300 cursor-pointer bg-white z-20 group text-left"
                  title={avada.title}
                >
                  <img
                    src={avada.imageUrl}
                    alt={avada.title}
                    className="w-full h-full object-cover object-top"
                  />
                  <div className="absolute bottom-2.5 left-2.5 bg-[#262626]/90 backdrop-blur-sm text-white px-2.5 py-1 rounded text-[11px] font-semibold flex items-center gap-1.5 shadow">
                    <Sparkles className="w-3 h-3 text-[#82B541]" />
                    <span>Avada · 1.07M+ Sales</span>
                  </div>
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
