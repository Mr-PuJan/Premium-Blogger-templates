import { useState } from 'react';
import {
  ShoppingCart,
  Heart,
  ChevronDown,
  Grid,
  Sparkles,
  Menu,
  X,
  User,
  ExternalLink,
} from 'lucide-react';
import { EnvatoMarketWordmark } from './EnvatoLogo';
import {
  ENVATO_MARKETS,
  HEADER_NAV_CATEGORIES,
  MainCategory,
} from '../data/marketplaceData';

interface HeaderProps {
  cartCount: number;
  favoritesCount: number;
  activeCategory: MainCategory;
  signedInUser: string | null;
  onGoHome: () => void;
  onSelectCategory: (cat: MainCategory, query?: string) => void;
  onOpenCart: () => void;
  onOpenFavorites: () => void;
  onOpenAuth: () => void;
  onOpenElements: () => void;
  onShowToast: (msg: string) => void;
}

export function Header({
  cartCount,
  favoritesCount,
  activeCategory,
  signedInUser,
  onGoHome,
  onSelectCategory,
  onOpenCart,
  onOpenFavorites,
  onOpenAuth,
  onOpenElements,
  onShowToast,
}: HeaderProps) {
  const [hoveredNav, setHoveredNav] = useState<string | null>(null);
  const [productsOpen, setProductsOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 w-full shadow-sm">
      {/* Tier 1: Envato Market Top Dark Bar */}
      <div className="bg-[#262626] text-[#999999] border-b border-[#333333]">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6 h-[48px] flex items-center justify-between gap-4">
          {/* Left: Envato Market Brand */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden text-white/80 hover:text-white p-1 -ml-1"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
            <button
              onClick={onGoHome}
              className="flex items-center focus:outline-none hover:opacity-95 transition-opacity cursor-pointer"
              title="ThemeForest — Home"
            >
              <EnvatoMarketWordmark size="md" />
            </button>
          </div>

          {/* Right: Forums, Start Selling, Our Products, Favorites, Cart, Sign In */}
          <div className="flex items-center gap-3 sm:gap-5 text-[13px]">
            <button
              onClick={() => onShowToast('Envato Community Forums — 142,000+ active discussions')}
              className="hidden md:inline-block hover:text-white transition-colors cursor-pointer"
            >
              Forums
            </button>
            <button
              onClick={() =>
                onShowToast('Start Selling on ThemeForest — Earn up to 87.5% author commission')
              }
              className="hidden md:inline-block hover:text-white transition-colors cursor-pointer"
            >
              Start Selling
            </button>

            {/* Our Products Dropdown */}
            <div
              className="relative hidden sm:block"
              onMouseEnter={() => setProductsOpen(true)}
              onMouseLeave={() => setProductsOpen(false)}
            >
              <button className="inline-flex items-center gap-1.5 hover:text-white transition-colors py-2 cursor-pointer">
                <Grid className="w-3.5 h-3.5 text-[#82B541]" />
                <span>Our Products</span>
                <ChevronDown className="w-3 h-3 opacity-70" />
              </button>
              {productsOpen && (
                <div className="absolute right-0 top-full w-64 bg-white text-[#333333] rounded-md shadow-xl border border-[#E1E8ED] py-2 z-50">
                  <button
                    onClick={() => {
                      setProductsOpen(false);
                      onOpenElements();
                    }}
                    className="w-full text-left px-4 py-2.5 hover:bg-[#F5F5F5] flex items-start justify-between gap-2 cursor-pointer"
                  >
                    <div>
                      <div className="text-[13px] font-bold text-[#262626] flex items-center gap-1.5">
                        Envato Elements
                        <span className="text-[10px] font-bold bg-[#82B541]/15 text-[#5C832C] px-1.5 py-0.5 rounded">
                          UNLIMITED
                        </span>
                      </div>
                      <div className="text-[11px] text-[#666666]">
                        Millions of creative assets &amp; AI tools
                      </div>
                    </div>
                    <ExternalLink className="w-3.5 h-3.5 text-[#999999] mt-0.5 shrink-0" />
                  </button>
                  <button
                    onClick={() => {
                      setProductsOpen(false);
                      onShowToast('Placeit by Envato — Smart Mockups, Logos & Video Templates');
                    }}
                    className="w-full text-left px-4 py-2 hover:bg-[#F5F5F5] cursor-pointer"
                  >
                    <div className="text-[13px] font-semibold text-[#262626]">Placeit by Envato</div>
                    <div className="text-[11px] text-[#666666]">Mockups, logos &amp; social templates</div>
                  </button>
                  <button
                    onClick={() => {
                      setProductsOpen(false);
                      onShowToast('Envato Tuts+ — Free tutorials, courses & guides');
                    }}
                    className="w-full text-left px-4 py-2 hover:bg-[#F5F5F5] cursor-pointer"
                  >
                    <div className="text-[13px] font-semibold text-[#262626]">Envato Tuts+</div>
                    <div className="text-[11px] text-[#666666]">Learn web design, WordPress &amp; code</div>
                  </button>
                </div>
              )}
            </div>

            {/* Favorites */}
            <button
              onClick={onOpenFavorites}
              className="relative inline-flex items-center gap-1.5 bg-[#333333] hover:bg-[#404040] text-[#E5E5E5] px-2.5 py-1.5 rounded text-[12px] font-medium transition-colors cursor-pointer"
              title="Saved Favorites"
            >
              <Heart className="w-3.5 h-3.5 text-rose-400" />
              <span className="hidden sm:inline">Favorites</span>
              {favoritesCount > 0 && (
                <span className="bg-rose-500 text-white text-[10px] font-bold px-1.5 py-0.2 rounded-full leading-tight">
                  {favoritesCount}
                </span>
              )}
            </button>

            {/* Cart Button */}
            <button
              onClick={onOpenCart}
              className="relative inline-flex items-center gap-1.5 bg-[#333333] hover:bg-[#404040] text-white px-2.5 py-1.5 rounded text-[12px] font-medium transition-colors cursor-pointer"
              title="Shopping Cart"
            >
              <ShoppingCart className="w-3.5 h-3.5 text-[#82B541]" />
              <span className="bg-[#82B541] text-white text-[10px] font-bold px-1.5 py-0.2 rounded-full leading-tight">
                {cartCount}
              </span>
            </button>

            {/* Sign In Button */}
            <button
              onClick={onOpenAuth}
              className="inline-flex items-center gap-1.5 bg-[#333333] hover:bg-[#444444] text-white px-3 py-1.5 rounded text-[12px] font-semibold transition-colors cursor-pointer"
            >
              <User className="w-3.5 h-3.5 text-[#82B541]" />
              <span>{signedInUser ? signedInUser : 'Sign In'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Tier 2: Marketplace Network Switcher Bar */}
      <div className="bg-[#262626] text-[#B3B3B3] hidden md:block">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6 h-[40px] flex items-center justify-between text-[13px]">
          <nav className="flex items-center gap-5 overflow-x-auto no-scrollbar">
            {ENVATO_MARKETS.map((market) => (
              <button
                key={market.label}
                onClick={() => {
                  if (market.active) {
                    onGoHome();
                  } else {
                    onShowToast(`Switched preview info: ${market.label} (${market.domain})`);
                  }
                }}
                className={`whitespace-nowrap py-2 transition-colors cursor-pointer relative ${
                  market.active
                    ? 'text-white font-semibold'
                    : 'hover:text-white text-[#A3A3A3]'
                }`}
              >
                {market.label}
                {market.active && (
                  <span className="absolute bottom-0 left-0 right-0 h-[2px] bg-[#82B541]" />
                )}
              </button>
            ))}
          </nav>

          <button
            onClick={onOpenElements}
            className="inline-flex items-center gap-1.5 text-[12px] text-[#E5E5E5] hover:text-white bg-[#333333] hover:bg-[#3D3D3D] px-3 py-1 rounded-full border border-[#454545] transition-colors cursor-pointer shrink-0"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#82B541]" />
            <span>AI Tools &amp; Unlimited Stock Assets</span>
          </button>
        </div>
      </div>

      {/* Tier 3: Category Mega-Menu Strip */}
      <div className="bg-[#F5F5F5] border-b border-[#E1E8ED] hidden lg:block">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6">
          <nav className="flex items-center justify-between h-[44px] text-[13px] font-medium text-[#555555]">
            <div className="flex items-center gap-1">
              {HEADER_NAV_CATEGORIES.map((item) => {
                const isSelected =
                  activeCategory !== 'All Items' &&
                  item.filterCategory === activeCategory &&
                  item.label === activeCategory;
                return (
                  <div
                    key={item.id}
                    className="relative"
                    onMouseEnter={() => setHoveredNav(item.id)}
                    onMouseLeave={() => setHoveredNav(null)}
                  >
                    <button
                      onClick={() => {
                        setHoveredNav(null);
                        onSelectCategory(item.filterCategory || 'All Items');
                      }}
                      className={`px-2.5 py-2.5 rounded-t transition-colors cursor-pointer whitespace-nowrap ${
                        isSelected || hoveredNav === item.id
                          ? 'bg-white text-[#262626] font-semibold'
                          : 'hover:text-[#262626] hover:bg-white/60'
                      }`}
                    >
                      {item.label}
                    </button>

                    {/* Mega Menu Dropdown */}
                    {hoveredNav === item.id && (
                      <div className="absolute left-0 top-full w-[260px] bg-white border border-[#E1E8ED] shadow-xl rounded-b-md py-2 z-50">
                        <div className="px-4 py-1.5 border-b border-[#F0F2F4] flex items-center justify-between">
                          <span className="text-[11px] font-bold uppercase tracking-wider text-[#888888]">
                            {item.label} Categories
                          </span>
                          <span className="text-[10px] font-semibold text-[#82B541] bg-[#82B541]/10 px-1.5 py-0.5 rounded">
                            {item.popularTag}
                          </span>
                        </div>
                        <div className="py-1">
                          {item.featuredSublinks.map((sub) => (
                            <button
                              key={sub.label}
                              onClick={() => {
                                setHoveredNav(null);
                                onSelectCategory(
                                  item.filterCategory || 'All Items',
                                  sub.query
                                );
                              }}
                              className="w-full px-4 py-1.5 text-left text-[13px] text-[#444444] hover:bg-[#F5F5F5] hover:text-[#262626] flex items-center justify-between cursor-pointer"
                            >
                              <span>{sub.label}</span>
                              <span className="text-[11px] text-[#999999]">{sub.count}</span>
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
            <div className="text-[12px] text-[#777777] hidden xl:flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-[#82B541]" />
              <span>58,000+ WordPress Themes &amp; Templates</span>
            </div>
          </nav>
        </div>
      </div>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white border-b border-[#E1E8ED] px-4 py-4 space-y-3 shadow-lg">
          <div className="text-[11px] font-bold uppercase tracking-wider text-[#888888]">
            Browse Categories
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {HEADER_NAV_CATEGORIES.slice(0, 12).map((cat) => (
              <button
                key={cat.id}
                onClick={() => {
                  onSelectCategory(cat.filterCategory || 'All Items');
                  setMobileMenuOpen(false);
                }}
                className="text-left px-3 py-2 rounded bg-[#F5F5F5] hover:bg-[#EAEAEA] text-[13px] font-medium text-[#333333]"
              >
                {cat.label}
              </button>
            ))}
          </div>
          <div className="pt-2 border-t border-[#EEEEEE] flex items-center justify-between">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenElements();
              }}
              className="text-[12px] font-semibold text-[#6F9A37] flex items-center gap-1"
            >
              <Sparkles className="w-3.5 h-3.5" />
              Envato Elements Unlimited
            </button>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onShowToast('Start Selling on ThemeForest');
              }}
              className="text-[12px] text-[#666666]"
            >
              Start Selling
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
