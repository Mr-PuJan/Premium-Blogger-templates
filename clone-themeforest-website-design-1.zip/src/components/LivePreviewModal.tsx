import { useState } from 'react';
import {
  Monitor,
  Tablet,
  Smartphone,
  X,
  ShoppingCart,
  ArrowRight,
  CheckCircle2,
  Sparkles,
} from 'lucide-react';
import { ThemeItem } from '../data/marketplaceData';
import { EnvatoMarketWordmark } from './EnvatoLogo';

interface LivePreviewModalProps {
  item: ThemeItem | null;
  allItems: ThemeItem[];
  onSwitchItem: (item: ThemeItem) => void;
  onClose: () => void;
  onBuyNow: (item: ThemeItem) => void;
}

export function LivePreviewModal({
  item,
  allItems,
  onSwitchItem,
  onClose,
  onBuyNow,
}: LivePreviewModalProps) {
  const [viewport, setViewport] = useState<'desktop' | 'tablet' | 'mobile'>('desktop');
  const [demoNotice, setDemoNotice] = useState<string | null>(null);

  if (!item) return null;

  const { demoConfig } = item;
  const isDark = Boolean(demoConfig.darkMode);

  const frameWidthClass =
    viewport === 'desktop'
      ? 'w-full'
      : viewport === 'tablet'
      ? 'w-[768px] max-w-full rounded-lg shadow-2xl border border-black/20'
      : 'w-[375px] max-w-full rounded-2xl shadow-2xl border-4 border-neutral-800';

  const triggerDemoClick = (msg: string) => {
    setDemoNotice(msg);
    setTimeout(() => setDemoNotice(null), 2600);
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#1A1A1A] flex flex-col">
      {/* Classic ThemeForest Preview Top Bar (#262626) */}
      <header className="h-[54px] bg-[#262626] border-b border-[#383838] px-4 flex items-center justify-between gap-4 shrink-0">
        <div className="flex items-center gap-4 min-w-0">
          <button
            type="button"
            onClick={onClose}
            className="shrink-0 cursor-pointer"
            title="Return to ThemeForest"
          >
            <EnvatoMarketWordmark size="sm" />
          </button>

          <select
            value={item.id}
            onChange={(e) => {
              const found = allItems.find((i) => i.id === Number(e.target.value));
              if (found) onSwitchItem(found);
            }}
            aria-label="Switch live preview theme"
            className="hidden sm:block max-w-[260px] bg-[#333333] text-[#E5E5E5] text-[12.5px] font-medium px-3 py-1.5 rounded border border-[#444444] focus:outline-none truncate cursor-pointer"
          >
            {allItems.map((t) => (
              <option key={t.id} value={t.id}>
                {t.title}
              </option>
            ))}
          </select>
        </div>

        {/* Center Responsive Viewport Switchers */}
        <div className="hidden md:flex items-center gap-1 bg-[#1D1D1D] p-1 rounded border border-[#383838]">
          <button
            type="button"
            onClick={() => setViewport('desktop')}
            title="Desktop View (100%)"
            className={`p-1.5 rounded cursor-pointer transition-colors ${
              viewport === 'desktop'
                ? 'bg-[#333333] text-white'
                : 'text-[#888888] hover:text-white'
            }`}
          >
            <Monitor className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => setViewport('tablet')}
            title="Tablet View (768px)"
            className={`p-1.5 rounded cursor-pointer transition-colors ${
              viewport === 'tablet'
                ? 'bg-[#333333] text-white'
                : 'text-[#888888] hover:text-white'
            }`}
          >
            <Tablet className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => setViewport('mobile')}
            title="Mobile View (375px)"
            className={`p-1.5 rounded cursor-pointer transition-colors ${
              viewport === 'mobile'
                ? 'bg-[#333333] text-white'
                : 'text-[#888888] hover:text-white'
            }`}
          >
            <Smartphone className="w-4 h-4" />
          </button>
        </div>

        {/* Right: Buy Now & Remove Frame */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={() => onBuyNow(item)}
            className="tf-btn-green px-4 py-1.5 rounded text-[13px] font-bold inline-flex items-center gap-1.5 cursor-pointer"
          >
            <ShoppingCart className="w-3.5 h-3.5" />
            <span>Buy now · ${item.price}</span>
          </button>

          <button
            type="button"
            onClick={onClose}
            className="text-[#AAAAAA] hover:text-white text-[12px] inline-flex items-center gap-1 px-2 py-1.5 rounded hover:bg-[#333333] cursor-pointer"
          >
            <X className="w-4 h-4" />
            <span className="hidden sm:inline">Remove Frame</span>
          </button>
        </div>
      </header>

      {/* Interactive Live Demo Canvas */}
      <div className="flex-1 overflow-auto p-0 sm:p-4 flex justify-center bg-[#121212]">
        <div
          className={`transition-all duration-300 overflow-y-auto flex flex-col min-h-full relative ${frameWidthClass} ${
            isDark ? 'bg-[#0B0F17] text-white' : 'bg-white text-[#1E293B]'
          }`}
        >
          {/* Demo Toast Feedback */}
          {demoNotice && (
            <div className="sticky top-3 z-30 mx-auto bg-[#262626] text-white px-4 py-2 rounded-full shadow-lg text-[12px] font-medium flex items-center gap-2 border border-[#82B541]/40">
              <CheckCircle2 className="w-4 h-4 text-[#82B541]" />
              <span>{demoNotice}</span>
            </div>
          )}

          {/* Demo Site Navbar */}
          <div
            className={`px-6 py-4 flex items-center justify-between border-b ${
              isDark ? 'border-white/10 bg-black/30' : 'border-slate-200 bg-white'
            }`}
          >
            <div className="flex items-center gap-2">
              <div
                className="w-7 h-7 rounded-md flex items-center justify-center text-white font-bold text-xs"
                style={{ backgroundColor: demoConfig.accentColor }}
              >
                {demoConfig.brandName.slice(0, 2)}
              </div>
              <span className="font-extrabold tracking-tight text-[15px]">
                {demoConfig.brandName}
              </span>
            </div>

            {viewport !== 'mobile' && (
              <div className="flex items-center gap-6 text-[13px] font-medium opacity-80">
                {['Home', 'Solutions', 'Showcase', 'Pricing', 'Contact'].map((link) => (
                  <button
                    key={link}
                    type="button"
                    onClick={() => triggerDemoClick(`Navigated to "${link}" section in ${demoConfig.brandName} live demo`)}
                    className="hover:opacity-100 cursor-pointer"
                  >
                    {link}
                  </button>
                ))}
              </div>
            )}

            <button
              type="button"
              onClick={() => triggerDemoClick(`Triggered "${demoConfig.ctaText}" demo interaction`)}
              className="px-3.5 py-1.5 rounded text-[12px] font-bold text-white cursor-pointer"
              style={{ backgroundColor: demoConfig.accentColor }}
            >
              {demoConfig.ctaText}
            </button>
          </div>

          {/* Demo Hero Section */}
          <div
            className="px-6 sm:px-12 py-12 sm:py-16"
            style={{
              background: isDark
                ? `radial-gradient(circle at top right, ${demoConfig.accentColor}30, transparent 55%)`
                : `linear-gradient(135deg, ${demoConfig.primaryColor}08, ${demoConfig.accentColor}14)`,
            }}
          >
            <div className="max-w-4xl mx-auto space-y-5">
              <div
                className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-bold uppercase tracking-wider"
                style={{
                  backgroundColor: `${demoConfig.accentColor}22`,
                  color: isDark ? '#FFFFFF' : demoConfig.primaryColor,
                }}
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>{demoConfig.tagline}</span>
              </div>

              <h1 className="text-[28px] sm:text-[42px] font-extrabold leading-[1.15] tracking-tight">
                {demoConfig.headline}
              </h1>
              <p className={`text-[16px] max-w-2xl leading-relaxed ${isDark ? 'text-slate-300' : 'text-slate-600'}`}>
                {demoConfig.subheadline}
              </p>

              <div className="flex flex-wrap items-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => triggerDemoClick(`Launched ${demoConfig.brandName} primary flow`)}
                  className="px-6 py-3 rounded-md font-bold text-[14px] text-white inline-flex items-center gap-2 shadow-md cursor-pointer"
                  style={{ backgroundColor: demoConfig.accentColor }}
                >
                  <span>{demoConfig.ctaText}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => onBuyNow(item)}
                  className={`px-5 py-3 rounded-md font-semibold text-[14px] border cursor-pointer ${
                    isDark
                      ? 'border-white/25 hover:bg-white/10 text-white'
                      : 'border-slate-300 hover:bg-slate-100 text-slate-800'
                  }`}
                >
                  License Theme (${item.price})
                </button>
              </div>

              {/* Stats Strip */}
              <div
                className={`grid grid-cols-3 gap-4 pt-6 mt-6 border-t ${
                  isDark ? 'border-white/10' : 'border-slate-200/80'
                }`}
              >
                {demoConfig.stats.map((st) => (
                  <div key={st.label}>
                    <div className="text-[20px] sm:text-[26px] font-extrabold">
                      {st.value}
                    </div>
                    <div className={`text-[12px] ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
                      {st.label}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Demo Cards / Featured Grid */}
          <div className="px-6 sm:px-12 py-10 max-w-5xl mx-auto w-full space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-[20px] font-bold">Interactive {item.subCategory} Showcase</h2>
              <span className="text-[12px] opacity-70">{item.softwareVersion}</span>
            </div>
            <div className={`grid gap-5 ${viewport === 'mobile' ? 'grid-cols-1' : 'grid-cols-3'}`}>
              {demoConfig.sampleCards.map((card, i) => (
                <div
                  key={i}
                  onClick={() => triggerDemoClick(`Opened "${card.title}" in ${demoConfig.brandName}`)}
                  className={`rounded-lg p-5 border transition-transform hover:-translate-y-1 cursor-pointer ${
                    isDark
                      ? 'bg-white/5 border-white/10 hover:border-white/25'
                      : 'bg-slate-50 border-slate-200 hover:shadow-md'
                  }`}
                >
                  <span
                    className="inline-block text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded text-white mb-3"
                    style={{ backgroundColor: demoConfig.accentColor }}
                  >
                    {card.tag}
                  </span>
                  <h3 className="font-bold text-[16px]">{card.title}</h3>
                  <p className={`text-[13px] mt-1 ${isDark ? 'text-slate-400' : 'text-slate-600'}`}>
                    {card.subtitle}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Footer inside Demo */}
          <div
            className={`mt-auto px-6 py-5 border-t text-center text-[12px] ${
              isDark ? 'border-white/10 text-slate-400' : 'border-slate-200 text-slate-500'
            }`}
          >
            Interactive Live Demo of <strong>{item.title}</strong> by{' '}
            <strong>{item.author}</strong> — Available exclusively on ThemeForest
          </div>
        </div>
      </div>
    </div>
  );
}
