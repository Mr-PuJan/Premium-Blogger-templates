import { useState } from 'react';
import {
  X,
  Trash2,
  ShoppingCart,
  ShieldCheck,
  CheckCircle2,
  Download,
} from 'lucide-react';
import { ThemeItem } from '../data/marketplaceData';
import { ThemeThumbnail } from './ThemeThumbnail';

export interface CartEntry {
  item: ThemeItem;
  license: 'regular' | 'extended';
  extendSupport: boolean;
}

interface CartDrawerProps {
  isOpen: boolean;
  entries: CartEntry[];
  onClose: () => void;
  onRemoveItem: (id: number) => void;
  onUpdateEntry: (id: number, license: 'regular' | 'extended', extendSupport: boolean) => void;
  onClearCart: () => void;
}

export function CartDrawer({
  isOpen,
  entries,
  onClose,
  onRemoveItem,
  onUpdateEntry,
  onClearCart,
}: CartDrawerProps) {
  const [checkedOut, setCheckedOut] = useState(false);

  if (!isOpen) return null;

  const subtotal = entries.reduce((sum, entry) => {
    const base =
      entry.license === 'regular' ? entry.item.price : entry.item.extendedPrice;
    const sup = entry.extendSupport ? entry.item.supportExtendPrice : 0;
    return sum + base + sup;
  }, 0);

  const handlingFee = entries.length > 0 ? 2.0 : 0;
  const grandTotal = +(subtotal + handlingFee).toFixed(2);

  const handleCheckout = () => {
    setCheckedOut(true);
    setTimeout(() => {
      onClearCart();
    }, 400);
  };

  const handleClose = () => {
    setCheckedOut(false);
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/50 backdrop-blur-[1px] flex justify-end"
      onClick={handleClose}
    >
      <div
        className="w-full max-w-[460px] bg-white h-full shadow-2xl flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-[#262626] text-white px-5 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <ShoppingCart className="w-5 h-5 text-[#82B541]" />
            <h2 className="text-[17px] font-bold">
              Your Shopping Cart ({entries.length})
            </h2>
          </div>
          <button
            type="button"
            onClick={handleClose}
            aria-label="Close cart"
            className="p-1.5 rounded hover:bg-[#383838] text-[#CCCCCC] hover:text-white cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-5 bg-[#F5F5F5]">
          {checkedOut ? (
            <div className="bg-white border border-[#DCE1E5] rounded-lg p-7 text-center space-y-4 my-6">
              <div className="w-14 h-14 rounded-full bg-[#82B541]/15 text-[#6F9A37] flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h3 className="text-[20px] font-bold text-[#262626]">
                Order Confirmed &amp; License Issued!
              </h3>
              <p className="text-[13.5px] text-[#555555] leading-relaxed">
                Your Envato Market purchase receipt, license PDF certificate, and ZIP download links are ready in your Downloads dashboard.
              </p>
              <button
                type="button"
                onClick={handleClose}
                className="tf-btn-green w-full py-2.5 rounded font-semibold text-[14px] inline-flex items-center justify-center gap-2 cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>Continue Browsing ThemeForest</span>
              </button>
            </div>
          ) : entries.length === 0 ? (
            <div className="bg-white border border-[#E1E8ED] rounded-lg p-8 text-center space-y-3 my-8">
              <ShoppingCart className="w-10 h-10 text-[#CCCCCC] mx-auto" />
              <h3 className="text-[17px] font-bold text-[#262626]">
                Your cart is empty
              </h3>
              <p className="text-[13.5px] text-[#666666]">
                Explore thousands of WordPress themes, Shopify stores, and UI templates to get started.
              </p>
              <button
                type="button"
                onClick={handleClose}
                className="tf-btn-green px-5 py-2 rounded text-[13px] font-semibold cursor-pointer"
              >
                Browse Themes
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {entries.map(({ item, license, extendSupport }) => {
                const linePrice = +(
                  (license === 'regular' ? item.price : item.extendedPrice) +
                  (extendSupport ? item.supportExtendPrice : 0)
                ).toFixed(2);

                return (
                  <div
                    key={item.id}
                    className="bg-white border border-[#E1E8ED] rounded-md p-4 space-y-3 shadow-xs"
                  >
                    <div className="flex gap-3">
                      <div className="w-24 aspect-[590/300] rounded overflow-hidden border border-[#EEEEEE] shrink-0">
                        <ThemeThumbnail item={item} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="text-[13.5px] font-bold text-[#262626] line-clamp-2 leading-snug">
                          {item.title}
                        </h4>
                        <p className="text-[12px] text-[#777777] mt-0.5">
                          by <span className="font-semibold">{item.author}</span>
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => onRemoveItem(item.id)}
                        aria-label="Remove item"
                        className="text-[#999999] hover:text-rose-500 p-1 self-start cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="flex items-center justify-between gap-2 pt-2 border-t border-[#F0F2F4]">
                      <select
                        value={license}
                        onChange={(e) =>
                          onUpdateEntry(
                            item.id,
                            e.target.value as 'regular' | 'extended',
                            extendSupport
                          )
                        }
                        className="text-[12px] font-medium text-[#333333] bg-[#F7F8F9] border border-[#DCE1E5] rounded px-2 py-1 focus:outline-none cursor-pointer"
                      >
                        <option value="regular">Regular License (${item.price})</option>
                        <option value="extended">
                          Extended License (${item.extendedPrice})
                        </option>
                      </select>

                      <span className="text-[16px] font-extrabold text-[#262626]">
                        ${linePrice}
                      </span>
                    </div>

                    <label className="flex items-center gap-2 text-[12px] text-[#555555] cursor-pointer">
                      <input
                        type="checkbox"
                        checked={extendSupport}
                        onChange={(e) =>
                          onUpdateEntry(item.id, license, e.target.checked)
                        }
                        className="accent-[#82B541]"
                      />
                      <span>
                        Extend support to 12 months (+${item.supportExtendPrice.toFixed(2)})
                      </span>
                    </label>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Cart Footer Summary */}
        {entries.length > 0 && !checkedOut && (
          <div className="bg-white border-t border-[#E1E8ED] p-5 space-y-3.5">
            <div className="space-y-1.5 text-[13px]">
              <div className="flex justify-between text-[#666666]">
                <span>Item Subtotal</span>
                <span>${subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-[#666666]">
                <span>Envato Handling Fee</span>
                <span>${handlingFee.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-[18px] font-extrabold text-[#262626] pt-2 border-t border-[#EEEEEE]">
                <span>Cart Total</span>
                <span>US$ {grandTotal.toFixed(2)}</span>
              </div>
            </div>

            <button
              type="button"
              onClick={handleCheckout}
              className="w-full tf-btn-green py-3 rounded font-bold text-[14.5px] cursor-pointer"
            >
              Go to Checkout
            </button>

            <div className="flex items-center justify-center gap-1.5 text-[11.5px] text-[#777777]">
              <ShieldCheck className="w-4 h-4 text-[#82B541]" />
              <span>Secure Envato Checkout · Instant License Download</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
