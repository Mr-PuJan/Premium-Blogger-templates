import { useState, useCallback } from 'react';
import { CheckCircle2 } from 'lucide-react';
import {
  MainCategory,
  THEME_ITEMS,
  ThemeItem,
} from './data/marketplaceData';
import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { CategoryTiles } from './components/CategoryTiles';
import { HomepageSections } from './components/HomepageSections';
import { CatalogView } from './components/CatalogView';
import { ItemDetailModal } from './components/ItemDetailModal';
import { LivePreviewModal } from './components/LivePreviewModal';
import { CartDrawer, CartEntry } from './components/CartDrawer';
import {
  AuthModal,
  ElementsModal,
  FavoritesDrawer,
} from './components/MarketplaceModals';
import { Footer } from './components/Footer';

export default function App() {
  // Navigation & Catalog state
  const [viewMode, setViewMode] = useState<'home' | 'catalog'>('home');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<MainCategory>('All Items');
  const [authorFilter, setAuthorFilter] = useState<string | null>(null);
  const [catalogSort, setCatalogSort] = useState<
    'bestseller' | 'newest' | 'rating' | 'price-asc' | 'price-desc'
  >('bestseller');

  // Marketplace interactive state
  const [cartEntries, setCartEntries] = useState<CartEntry[]>([]);
  const [favoriteIds, setFavoriteIds] = useState<number[]>([2833226, 20264492]);
  const [signedInUser, setSignedInUser] = useState<string | null>(null);

  // Modals & Drawers
  const [inspectedItem, setInspectedItem] = useState<ThemeItem | null>(null);
  const [livePreviewItem, setLivePreviewItem] = useState<ThemeItem | null>(null);
  const [cartOpen, setCartOpen] = useState(false);
  const [favoritesOpen, setFavoritesOpen] = useState(false);
  const [authOpen, setAuthOpen] = useState(false);
  const [elementsOpen, setElementsOpen] = useState(false);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const showToast = useCallback((msg: string) => {
    setToastMsg(msg);
    setTimeout(() => {
      setToastMsg((prev) => (prev === msg ? null : prev));
    }, 3000);
  }, []);

  const handleGoHome = () => {
    setViewMode('home');
    setSearchQuery('');
    setActiveCategory('All Items');
    setAuthorFilter(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenCatalog = (
    cat: MainCategory = 'All Items',
    sort?: 'newest' | 'bestseller',
    author?: string,
    query?: string
  ) => {
    setActiveCategory(cat);
    if (sort) setCatalogSort(sort);
    setAuthorFilter(author || null);
    if (typeof query === 'string') setSearchQuery(query);
    setViewMode('catalog');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleHeroSearchSubmit = (customQuery?: string) => {
    if (typeof customQuery === 'string') {
      setSearchQuery(customQuery);
    }
    setAuthorFilter(null);
    setViewMode('catalog');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleAddToCart = (
    item: ThemeItem,
    license: 'regular' | 'extended' = 'regular',
    extendSupport = false
  ) => {
    const existing = cartEntries.find((e) => e.item.id === item.id);
    if (existing) {
      // Update license/support if changed or open cart
      setCartEntries((prev) =>
        prev.map((e) =>
          e.item.id === item.id ? { ...e, license, extendSupport } : e
        )
      );
      setCartOpen(true);
      return;
    }

    setCartEntries((prev) => [...prev, { item, license, extendSupport }]);
    showToast(`Added "${item.title.split(/[-|]/)[0].trim()}" to your cart`);
  };

  const handleBuyNow = (
    item: ThemeItem,
    license: 'regular' | 'extended' = 'regular',
    extendSupport = false
  ) => {
    const exists = cartEntries.some((e) => e.item.id === item.id);
    if (!exists) {
      setCartEntries((prev) => [...prev, { item, license, extendSupport }]);
    } else {
      setCartEntries((prev) =>
        prev.map((e) =>
          e.item.id === item.id ? { ...e, license, extendSupport } : e
        )
      );
    }
    setInspectedItem(null);
    setLivePreviewItem(null);
    setCartOpen(true);
  };

  const handleToggleFavorite = (item: ThemeItem) => {
    setFavoriteIds((prev) => {
      const exists = prev.includes(item.id);
      if (exists) {
        showToast(`Removed "${item.title.split(/[-|]/)[0].trim()}" from favorites`);
        return prev.filter((id) => id !== item.id);
      }
      showToast(`Saved "${item.title.split(/[-|]/)[0].trim()}" to favorites`);
      return [...prev, item.id];
    });
  };

  const cartIds = cartEntries.map((e) => e.item.id);
  const favoriteItems = THEME_ITEMS.filter((i) => favoriteIds.includes(i.id));

  return (
    <div className="min-h-screen flex flex-col bg-white text-[#333333]">
      {/* Authentic 3-Tier ThemeForest Header */}
      <Header
        cartCount={cartEntries.length}
        favoritesCount={favoriteIds.length}
        activeCategory={activeCategory}
        signedInUser={signedInUser}
        onGoHome={handleGoHome}
        onSelectCategory={(cat, query) =>
          handleOpenCatalog(cat, undefined, undefined, query ?? '')
        }
        onOpenCart={() => setCartOpen(true)}
        onOpenFavorites={() => setFavoritesOpen(true)}
        onOpenAuth={() => setAuthOpen(true)}
        onOpenElements={() => setElementsOpen(true)}
        onShowToast={showToast}
      />

      <main className="flex-1">
        {viewMode === 'home' ? (
          <>
            <HeroSection
              searchQuery={searchQuery}
              searchCategory={activeCategory}
              onSearchQueryChange={setSearchQuery}
              onSearchCategoryChange={setActiveCategory}
              onSubmitSearch={handleHeroSearchSubmit}
              featuredShowcaseItems={THEME_ITEMS}
              onInspectItem={(item) => setInspectedItem(item)}
            />

            <CategoryTiles
              onSelectCategory={(cat, sort) => handleOpenCatalog(cat, sort)}
            />

            <HomepageSections
              allItems={THEME_ITEMS}
              cartIds={cartIds}
              favoriteIds={favoriteIds}
              onInspect={(item) => setInspectedItem(item)}
              onLivePreview={(item) => setLivePreviewItem(item)}
              onAddToCart={(item) => handleAddToCart(item)}
              onToggleFavorite={handleToggleFavorite}
              onOpenCatalog={(cat, sort, author) =>
                handleOpenCatalog(cat || 'All Items', sort, author)
              }
              onOpenElements={() => setElementsOpen(true)}
            />
          </>
        ) : (
          <CatalogView
            allItems={THEME_ITEMS}
            searchQuery={searchQuery}
            selectedCategory={activeCategory}
            authorFilter={authorFilter}
            sortBy={catalogSort}
            cartIds={cartIds}
            favoriteIds={favoriteIds}
            onSearchQueryChange={setSearchQuery}
            onSelectCategory={setActiveCategory}
            onChangeSort={setCatalogSort}
            onClearAuthor={() => setAuthorFilter(null)}
            onResetToHome={handleGoHome}
            onInspect={(item) => setInspectedItem(item)}
            onLivePreview={(item) => setLivePreviewItem(item)}
            onAddToCart={(item) => handleAddToCart(item)}
            onToggleFavorite={handleToggleFavorite}
            onFilterByAuthor={(author) => handleOpenCatalog('All Items', undefined, author)}
          />
        )}
      </main>

      {/* Authentic ThemeForest Dark Footer */}
      <Footer onGoHome={handleGoHome} onShowToast={showToast} />

      {/* Item Details Modal */}
      <ItemDetailModal
        item={inspectedItem}
        isInCart={inspectedItem ? cartIds.includes(inspectedItem.id) : false}
        isFavorite={inspectedItem ? favoriteIds.includes(inspectedItem.id) : false}
        onClose={() => setInspectedItem(null)}
        onAddToCart={handleAddToCart}
        onBuyNow={handleBuyNow}
        onLivePreview={(item) => {
          setInspectedItem(null);
          setLivePreviewItem(item);
        }}
        onToggleFavorite={handleToggleFavorite}
        onFilterByAuthor={(author) => handleOpenCatalog('All Items', undefined, author)}
      />

      {/* Live Preview Top Bar & Interactive Theme Renderer */}
      <LivePreviewModal
        item={livePreviewItem}
        allItems={THEME_ITEMS}
        onSwitchItem={setLivePreviewItem}
        onClose={() => setLivePreviewItem(null)}
        onBuyNow={(item) => handleBuyNow(item)}
      />

      {/* Slide-Over Shopping Cart Drawer */}
      <CartDrawer
        isOpen={cartOpen}
        entries={cartEntries}
        onClose={() => setCartOpen(false)}
        onRemoveItem={(id) =>
          setCartEntries((prev) => prev.filter((e) => e.item.id !== id))
        }
        onUpdateEntry={(id, license, extendSupport) =>
          setCartEntries((prev) =>
            prev.map((e) =>
              e.item.id === id ? { ...e, license, extendSupport } : e
            )
          )
        }
        onClearCart={() => setCartEntries([])}
      />

      {/* Favorites Drawer */}
      <FavoritesDrawer
        isOpen={favoritesOpen}
        items={favoriteItems}
        cartIds={cartIds}
        onClose={() => setFavoritesOpen(false)}
        onRemoveFavorite={handleToggleFavorite}
        onAddToCart={(item) => handleAddToCart(item)}
        onInspect={(item) => setInspectedItem(item)}
        onLivePreview={(item) => setLivePreviewItem(item)}
      />

      {/* Envato Sign In Modal */}
      <AuthModal
        isOpen={authOpen}
        signedInUser={signedInUser}
        onClose={() => setAuthOpen(false)}
        onSignIn={(user) => {
          setSignedInUser(user);
          showToast(`Welcome back, ${user}!`);
        }}
        onSignOut={() => {
          setSignedInUser(null);
          showToast('Signed out of Envato Market');
        }}
      />

      {/* Envato Elements Unlimited Comparison Modal */}
      <ElementsModal
        isOpen={elementsOpen}
        onClose={() => setElementsOpen(false)}
        onShowToast={showToast}
      />

      {/* Floating Marketplace Toast Notification */}
      {toastMsg && (
        <div className="fixed bottom-5 right-5 z-50 bg-[#262626] text-white px-4 py-3 rounded-md shadow-xl border border-[#3E3E3E] flex items-center gap-2.5 text-[13px] font-medium max-w-sm">
          <CheckCircle2 className="w-4 h-4 text-[#82B541] shrink-0" />
          <span>{toastMsg}</span>
        </div>
      )}
    </div>
  );
}
